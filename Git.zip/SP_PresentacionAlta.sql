CREATE PROCEDURE AltaPresentacion
	@Id_Equipos [int],
	@Id_Marcas [int],
	@Id_Tipo_Producto [int],
	@Id_Medidas_Tallas [int],
	@Id_Productos [int]
AS
BEGIN
	BEGIN TRAN
		INSERT INTO Presentacion(Id_Equipos, Id_Marca, Id_Tipo_Producto, Id_Medidas_Tallas, Id_Productos)
		VALUES (@Id_Equipos, @Id_Marcas, @Id_Tipo_Producto, @Id_Medidas_Tallas, @Id_Productos)
	COMMIT TRAN
END
