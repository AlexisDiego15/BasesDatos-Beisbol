USE Baseball_Store
GO

CREATE PROCEDURE Consulta_Colonia
    @CP varchar(5),
	@CurrencyCursor CURSOR VARYING OUTPUT AS
BEGIN 
	SET NOCOUNT ON;  
    SET @CurrencyCursor = CURSOR  
    FORWARD_ONLY STATIC FOR  
      SELECT Descripcion_Asentamiento  
      FROM SEPOMEX
	  WHERE CP = @CP;  
    OPEN @CurrencyCursor;  
END

DECLARE @MyCursor CURSOR;  
EXEC Consulta_Colonia '08760', @CurrencyCursor = @MyCursor OUTPUT;  
WHILE (@@FETCH_STATUS = 0)  
BEGIN;  
     FETCH NEXT FROM @MyCursor;  
END;  
CLOSE @MyCursor;  
DEALLOCATE @MyCursor;  




