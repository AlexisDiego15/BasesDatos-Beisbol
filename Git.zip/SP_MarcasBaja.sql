CREATE PROCEDURE Baja_Marca
	@Id_Marca int
	 AS
BEGIN
    BEGIN TRAN
		BEGIN TRY
			IF (SELECT Estatus FROM Marcas WHERE Id_Marca = @Id_Marca) = 1
				UPDATE Marcas SET Estatus = 0 WHERE Id_Marca = @Id_Marca
			ELSE
				UPDATE Marcas SET Estatus = 1 WHERE Id_Marca = @Id_Marca
		END TRY
		BEGIN CATCH
      SELECT 'No se pudo realizar el cambio de estatus del registro' AS msj
			ROLLBACK
		END CATCH
	COMMIT TRAN
END
