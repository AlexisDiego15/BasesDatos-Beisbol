CREATE PROCEDURE Baja_Equipo
	@Id_Equipo int
	 AS
BEGIN
    BEGIN TRAN
		BEGIN TRY
			IF (SELECT Estatus FROM Equipos WHERE Id_Equipos = @Id_Equipo) = 1
				UPDATE Equipos SET Estatus = 0 WHERE Id_Equipos = @Id_Equipo
			ELSE
				UPDATE Equipos SET Estatus = 1 WHERE Id_Equipos = @Id_Equipo
		END TRY
		BEGIN CATCH
      SELECT 'No se pudo realizar el cambio de estatus del registro' AS msj
			ROLLBACK
		END CATCH
	COMMIT TRAN
END
