CREATE PROCEDURE Alta_Equipo
	@Descripcion varchar(50)
	 AS
BEGIN
	 	  BEGIN TRAN
	 	     IF(SELECT COUNT(*) FROM Equipos WHERE Descripcion=@Descripcion) < 1
	 	     BEGIN
	 	       BEGIN TRY
	 	         INSERT INTO Equipos(Descripcion) VALUES (@Descripcion)
	 	       END TRY
	 	       BEGIN CATCH
	 	         SELECT 'Error al dar de alta' AS msj
	 	         ROLLBACK
	 	       END CATCH
	 	     END
	 	     ELSE
	 	     BEGIN
	 	       SELECT 'Ese equipos ya esta registrado' AS msj
	 	       ROLLBACK
	 	     END
	 	 	COMMIT TRAN
END
