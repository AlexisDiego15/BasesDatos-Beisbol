CREATE PROCEDURE Altas_ProveedoresTelefonos
    @Id_Proveedor int,
	@Telefono varchar(10)
	AS
BEGIN 
    BEGIN TRAN

		INSERT INTO Telefonos_Proveedores(Telefono,Id_Proveedor)
		VALUES (@Telefono, (select Id_Proveedor from Proveedores where Id_Proveedor = @Id_Proveedor))

    COMMIT TRAN
END