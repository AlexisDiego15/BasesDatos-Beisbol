CREATE PROCEDURE Baja_Tipo_Producto
	@Id_Tipo_Producto int
	 AS
BEGIN
    BEGIN TRAN
		BEGIN TRY
			IF (SELECT Estatus FROM Tipo_Producto WHERE Id_Tipo_Producto = @Id_Tipo_Producto) = 1
				UPDATE Tipo_Producto SET Estatus = 0 WHERE Id_Tipo_Producto = @Id_Tipo_Producto
			ELSE
				UPDATE Tipo_Producto SET Estatus = 1 WHERE Id_Tipo_Producto = @Id_Tipo_Producto
		END TRY
		BEGIN CATCH
      SELECT 'No se pudo realizar el cambio de estatus del registro' AS msj
			ROLLBACK
		END CATCH
	COMMIT TRAN
END
