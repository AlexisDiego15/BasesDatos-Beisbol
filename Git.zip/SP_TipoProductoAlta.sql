CREATE PROCEDURE Alta_Tipo_Producto
  @Id_Categoria [int],
	@Descripcion [varchar](50)
	 AS
BEGIN
  BEGIN TRAN
    IF(SELECT COUNT(*) FROM Tipo_Producto WHERE Descripcion=@Descripcion AND Id_Categoria=@Id_Categoria) < 1
    BEGIN
      BEGIN TRY
        INSERT INTO Tipo_Producto(Descripcion,Id_Categoria) VALUES (@Descripcion,@Id_Categoria)
      END TRY
      BEGIN CATCH
        SELECT 'Error al dar de alta' AS msj
        ROLLBACK
      END CATCH
    END
    ELSE
    BEGIN
      SELECT 'Ese tipo de producto ya esta registrado' AS msj
      ROLLBACK
    END
	COMMIT TRAN
END
