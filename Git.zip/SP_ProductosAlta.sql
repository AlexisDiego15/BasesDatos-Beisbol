CREATE PROCEDURE Alta_Productos
	@Nombre [varchar](50),
	@Precio_Compra [int],
	@Precio_Venta [int],
	@Id_Presentacion [int],
	@Id_Proveedor [int]

AS
BEGIN
	BEGIN TRAN
		INSERT INTO Productos(Nombre, Precio_Compra, Precio_Venta, Id_Proveedor)
		VALUES (@Nombre, @Precio_Compra, @Precio_Venta, @Id_Proveedor)
	COMMIT TRAN
END
