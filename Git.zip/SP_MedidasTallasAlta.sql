CREATE PROCEDURE Alta_Medida_Talla
	@Talla varchar(15)
	 AS
BEGIN
	  BEGIN TRAN
	     IF(SELECT COUNT(*) FROM Medidas_Tallas WHERE Talla = @Talla) < 1
	     BEGIN
	       BEGIN TRY
	         INSERT INTO Medidas_Tallas(Talla) VALUES (@Talla)
	       END TRY
	       BEGIN CATCH
	         SELECT 'Error al dar de alta' AS msj
	         ROLLBACK
	       END CATCH
	     END
	     ELSE
	     BEGIN
	       SELECT 'Esa categoria ya esta registrada' AS msj
	       ROLLBACK
	     END
	 	COMMIT TRAN
END
