CREATE PROCEDURE Modificar_Equipo
	@NuevaDescripcion varchar(50),
	@Id_Equipo int
	 AS
BEGIN
    BEGIN TRAN
		BEGIN TRY
			UPDATE Equipos SET Descripcion = @NuevaDescripcion WHERE Id_Equipos = @Id_Equipo
		END TRY
		BEGIN CATCH
			SELECT 'No se pudo realizar la modificacion al registro' AS msj
			ROLLBACK
		END CATCH
	COMMIT TRAN
END
