CREATE PROCEDURE Modificar_Cliente
    @Id_Cliente [int],
    @Nombre varchar(50),
    @ApellidosP varchar(50),
    @ApellidosM varchar(50),
    @Nombre_Usuario varchar(50),
    @Correo varchar(320),
    @Telefono varchar(10),
    @Contrasena varchar(20),
    @Calle  [nvarchar](40),
    @No_Int [int],
    @No_Ext [int],
    @CP [varchar] (5),
    @Descripcion_Asentamiento [nvarchar](80) AS
BEGIN
    BEGIN TRAN
    BEGIN TRY

      UPDATE Clientes SET Nombre = @Nombre,
                          Apellidos_Paterno = @ApellidosP,
                          Apellidos_Materno = @ApellidosM,
                          Nombre_Usuario = @Nombre_Usuario,
                          Email = @Correo,
                          Telefono = @Telefono,
                          Contrasena = @Contrasena,
                          Calle = @Calle,
                          No_Int = @No_Int,
                          No_Ext = @No_Ext,
                          CP = @CP,
                          Id_Asentamiento = (SELECT Id_Asentamiento FROM SEPOMEX WHERE CP = @CP AND Descripcion_Asentamiento = @Descripcion_Asentamiento)
                        WHERE Id_Cliente = @Id_Cliente
    END TRY

    BEGIN CATCH
      SELECT 'Error al actualizar datos' AS msj
    END CATCH

    COMMIT TRAN
END
