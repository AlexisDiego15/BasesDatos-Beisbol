package Paneles;

import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import rsbuttom.CustomScrollBarUI;

public class pnl_pres_categoria extends javax.swing.JPanel {

    DefaultTableModel modelo;  
    
    public pnl_pres_categoria() {
        initComponents();
        tablaComponentes();
        llenarTabla();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ScrollPane = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txt_marca_alta = new javax.swing.JTextField();
        btn_agregar = new rsbuttom.RSButtonMetro();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txt_eliminar = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        btn_eliminar = new rsbuttom.RSButtonMetro();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        btn_guardarcambio = new rsbuttom.RSButtonMetro();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_marca_nueva = new javax.swing.JTextField();
        txt_marca_ant = new javax.swing.JTextField();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(960, 580));

        ScrollPane.setBackground(new java.awt.Color(255, 255, 255));
        ScrollPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ScrollPaneMouseClicked(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Marca", "Nombre"
            }
        ){public boolean isCellEditable(int row, int column){
            return false;}
    });
    tabla.setAlignmentX(0.0F);
    tabla.setAlignmentY(0.0F);
    tabla.setAutoscrolls(false);
    tabla.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            tablaMouseClicked(evt);
        }
    });
    ScrollPane.setViewportView(tabla);

    jPanel1.setBackground(new java.awt.Color(255, 255, 255));

    jPanel2.setBackground(new java.awt.Color(255, 255, 255));

    jLabel1.setText("Agregar nueva categoria");

    txt_marca_alta.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            txt_marca_altaActionPerformed(evt);
        }
    });

    btn_agregar.setText("Agregar");
    btn_agregar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btn_agregarActionPerformed(evt);
        }
    });

    jLabel2.setText("Categoria:");

    javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
    jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(57, 57, 57)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(txt_marca_alta, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(43, 43, 43)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
            .addGap(0, 0, Short.MAX_VALUE)
            .addComponent(btn_agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(141, 141, 141))
    );
    jPanel2Layout.setVerticalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addComponent(jLabel1)
                    .addGap(18, 18, 18)
                    .addComponent(txt_marca_alta, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(26, 26, 26)
            .addComponent(btn_agregar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(40, Short.MAX_VALUE))
    );

    jPanel3.setBackground(new java.awt.Color(255, 255, 255));

    jLabel3.setText("Seleccione la categoria que desea eliminar y despues confirme");

    txt_eliminar.setDisabledTextColor(new java.awt.Color(0, 0, 0));
    txt_eliminar.setEnabled(false);
    txt_eliminar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            txt_eliminarActionPerformed(evt);
        }
    });

    jLabel4.setText("Marca:");

    btn_eliminar.setText("Eliminar");
    btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btn_eliminarActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
    jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addGap(59, 59, 59)
            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addComponent(btn_eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                .addComponent(txt_eliminar))
            .addGap(149, 149, 149))
    );
    jPanel3Layout.setVerticalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel3)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addComponent(txt_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGap(32, 32, 32)
            .addComponent(btn_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(44, Short.MAX_VALUE))
    );

    jLabel5.setText("Seleccione la categoria que desea modificar y escriba su nuevo nombre");

    btn_guardarcambio.setText("Guardar cambios");
    btn_guardarcambio.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btn_guardarcambioActionPerformed(evt);
        }
    });

    jLabel6.setText(" Categoria:");

    jLabel7.setText("Nueva Categoria:");

    txt_marca_nueva.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            txt_marca_nuevaActionPerformed(evt);
        }
    });

    txt_marca_ant.setDisabledTextColor(new java.awt.Color(0, 0, 0));
    txt_marca_ant.setEnabled(false);
    txt_marca_ant.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            txt_marca_antActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
    jPanel4.setLayout(jPanel4Layout);
    jPanel4Layout.setHorizontalGroup(
        jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel4Layout.createSequentialGroup()
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(47, 47, 47)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txt_marca_ant, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(btn_guardarcambio, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addGap(47, 47, 47)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(26, 26, 26))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)))
                    .addComponent(txt_marca_nueva, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addContainerGap(59, Short.MAX_VALUE))
    );
    jPanel4Layout.setVerticalGroup(
        jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel4Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel5)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(txt_marca_ant, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(24, 24, 24)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(jLabel7)
                .addComponent(txt_marca_nueva, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
            .addComponent(btn_guardarcambio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(28, 28, 28))
    );

    javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
    jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(
        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );
    jPanel1Layout.setVerticalGroup(
        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    );

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
    this.setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addComponent(ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(ScrollPane)
        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );
    }// </editor-fold>//GEN-END:initComponents

    private void ScrollPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ScrollPaneMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ScrollPaneMouseClicked

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        int row = tabla.getSelectedRow();
        String descripcion = tabla.getValueAt(row, 1).toString();
        
        txt_eliminar.setText(descripcion);
        txt_marca_ant.setText(descripcion);
    }//GEN-LAST:event_tablaMouseClicked

    private void btn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarActionPerformed
        if(txt_marca_alta.getText().length()!=0){
            int ax = JOptionPane.showConfirmDialog(null, "¿Seguro que desea agregar esta categoria?");
                if (ax == JOptionPane.YES_OPTION) {
                    ModeloNegocio.Presentaciones mn = new ModeloNegocio.Presentaciones();
                    mn.AltCategoria(txt_marca_alta.getText());
                    txt_marca_alta.setText("");
                    llenarTabla();
                }
        }else
            JOptionPane.showMessageDialog(null, "Escribe una categoria valida");
    }//GEN-LAST:event_btn_agregarActionPerformed

    private void txt_marca_altaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_marca_altaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_marca_altaActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        if(txt_eliminar.getText().length()!=0){
            int ax = JOptionPane.showConfirmDialog(null, "¿Seguro que desea eliminarla?");
                if (ax == JOptionPane.YES_OPTION) {
                    ModeloNegocio.Presentaciones mn = new ModeloNegocio.Presentaciones();
                    mn.BajaCategoria(txt_eliminar.getText());
                    txt_eliminar.setText("");
                    txt_marca_nueva.setText("");
                    txt_marca_ant.setText("");
                    llenarTabla();
                }
        }else
            JOptionPane.showMessageDialog(null, "Selecciona una categoria valida");
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void txt_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_eliminarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_eliminarActionPerformed

    private void btn_guardarcambioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarcambioActionPerformed
        if(txt_marca_ant.getText().length()!=0 && txt_marca_nueva.getText().length()!=0){
            int ax = JOptionPane.showConfirmDialog(null, "¿Seguro que desea cambiar el nombre?, Se cambiará en todos los productos");
                if (ax == JOptionPane.YES_OPTION) {
                  //ModeloNegocio.Presentaciones mn = new ModeloNegocio.Presentaciones();
                  //mn.CambiarMarca(txt_marca_ant.getText(), txt_marca_nueva.getText());
                    txt_eliminar.setText("");
                    txt_marca_nueva.setText("");
                    txt_marca_ant.setText("");
                    llenarTabla();
                }
        }else
            JOptionPane.showMessageDialog(null, "Selecciona o escribe una categoria valida");
    }//GEN-LAST:event_btn_guardarcambioActionPerformed

    private void txt_marca_nuevaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_marca_nuevaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_marca_nuevaActionPerformed

    private void txt_marca_antActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_marca_antActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_marca_antActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane ScrollPane;
    private rsbuttom.RSButtonMetro btn_agregar;
    private rsbuttom.RSButtonMetro btn_eliminar;
    private rsbuttom.RSButtonMetro btn_guardarcambio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField txt_eliminar;
    private javax.swing.JTextField txt_marca_alta;
    private javax.swing.JTextField txt_marca_ant;
    private javax.swing.JTextField txt_marca_nueva;
    // End of variables declaration//GEN-END:variables

    public void tablaComponentes() {
        
        ScrollPane.getVerticalScrollBar().setUI(new CustomScrollBarUI());
        Color color, fuente;
        color = new Color(41, 100, 185);
        fuente = new Color(120, 115, 200);
        String[] columnNames = {"ID Categoria", "Nombre Categoria"};

        modelo = new DefaultTableModel(null, columnNames){
            @Override
            public boolean isCellEditable(int i, int i1) {
                return false;
            }
        };

        modelo.setColumnIdentifiers(columnNames);
        tabla.setAutoCreateRowSorter(true);   
        tabla.getTableHeader().setOpaque(false);
        tabla.getTableHeader().setBackground(fuente);
        tabla.getTableHeader().setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, color));
        tabla.getTableHeader().setForeground(Color.WHITE);
        tabla.setRowHeight(40);
        
        tabla.getColumnModel().getColumn(0).setPreferredWidth(150);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(350);
        
    }

    public void llenarTabla() {
    BD.conexionsql sq = new BD.conexionsql();
        while (modelo.getRowCount()>0){
             modelo.removeRow(0);
        }
        try {
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("select * from Categorias order by Id_Categoria");
            while (rsUsr.next()) {
                modelo.addRow(new Object[]{rsUsr.getInt("Id_Categoria"), rsUsr.getString("Descripcion")});
            }
             tabla.setModel(modelo);
        }catch (SQLException ex) {
            System.out.println(ex.getErrorCode());
        }
    }
}