package ModeloNegocio;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Presentaciones {
    public String msj;
    BD.conexionsql sq = new BD.conexionsql();

    public void AltaMarca(String marca){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Alta_Marcas '"+marca+"'");
            while (rsUsr.next()) {
                
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, "Ok");
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    public void BajaMarca(String marca){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Baja_Marca '"+marca+"'");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }   
    public void CambiarMarca(String anterior, String nueva){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }    
    
    public void AltaEquipo(String equipo){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Alta_Equipo '"+equipo+"'");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    public void CambiarEquipo(int anterior, String nuevo){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("EXECUTE Modificar_Equipo '"+nuevo+"',"+anterior+"");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }  
    public void BajaEquipo(int equipo){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("EXECUTE Baja_Equipo "+equipo+"");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }   
    
    public void AltaTalla(String talla){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Alta_Medida_Talla '"+talla+"'");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    public void BajaTalla(String talla){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Baja_Medida_Talla '"+talla+"'");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }   
    public void CambiarTalla(String anterior, String nueva){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }  
    
    public void AltCategoria(String categoria){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Alta_Categoria '"+categoria+"'");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    public void BajaCategoria(String categoria){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Baja_Categoria '"+categoria+"'");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }   
    public void CambiarCategoria(String anterior, String nueva){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }  
    
    public void AltaTipo(String tipo, String categoria){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Alta_Tipo_Producto '"+categoria+"', '"+tipo+"'");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    public void BajaTipo(String tipo){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("exec Baja_Tipo_Producto '"+tipo+"'");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }   
    public void CambiarTipo(String anterior_t, String nuevo_t, String categoria){
        try{
            sq.estableceConnectionString();
            sq.conectar();
        
            ResultSet rsUsr;
            rsUsr = sq.consulta("");
            while (rsUsr.next()) {
                msj=rsUsr.getString("msj");
                JOptionPane.showMessageDialog(null, msj);
                
                sq.cierraConexion();
                rsUsr.close();
            }
        }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }  
    
}
