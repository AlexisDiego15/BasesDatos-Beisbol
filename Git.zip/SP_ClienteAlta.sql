--SP Clientes
use Baseball_Store
GO

CREATE PROCEDURE Altas_Cliente
    @Nombre varchar(50),
    @ApellidosP varchar(50),
    @ApellidosM varchar(50),
    @Nombre_Usuario varchar(50),
    @Correo varchar(320),
    @Telefono varchar(10), 
    @Contrase�a varchar(20) AS
BEGIN 
    BEGIN TRAN
    Insert into Clientes(Nombre,Nombre_Usuario,Apellidos_Paterno,Apellidos_Materno,Email,Telefono,Contrasena)
    Values (@Nombre,@Nombre_Usuario,@ApellidosP,@ApellidosM,@Correo,@Telefono,@Contrase�a)

    COMMIT TRAN
END
