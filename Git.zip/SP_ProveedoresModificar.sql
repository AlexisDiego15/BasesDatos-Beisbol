CREATE PROCEDURE Modificar_Proveedores
  @Id_Proveedor int,
  @Nombre varchar(50),
  @ApellidosP varchar(50),
  @ApellidosM varchar(50),
  @Calle nvarchar(40),
  @No_Int int,
  @No_Ext int,
  @CP varchar(5),
  @Descripcion_Asenta varchar(100)
  AS
  BEGIN
    BEGIN TRAN

      UPDATE Proveedores SET Nombre = @Nombre,
                              ApellidosP = @ApellidosP,
                              ApellidosM = @ApellidosM,
                              Calle = @Calle,
                              No_Int = @No_Int,
                              No_Ext = @No_Ext,
                              CP = @CP,
                              Id_Asentamiento = (select id_asentamiento from SEPOMEX where cp = @CP and Descripcion_Asentamiento = @Descripcion_Asenta)
                              WHERE Id_Proveedor = @Id_Proveedor

    COMMIT TRAN
  END
