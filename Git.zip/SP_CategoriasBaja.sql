CREATE PROCEDURE Baja_Categoria
	@Id_Categoria int
	 AS
BEGIN
    BEGIN TRAN
		BEGIN TRY
			IF (SELECT Estatus FROM Categorias WHERE Id_Categoria = @Id_Categoria) = 1
				UPDATE Categorias SET Estatus = 0 WHERE Id_Categoria = @Id_Categoria
			ELSE
				UPDATE Categorias SET Estatus = 1 WHERE Id_Categoria = @Id_Categoria
		END TRY
		BEGIN CATCH
      SELECT 'No se pudo realizar el cambio de estatus del registro' AS msj
			ROLLBACK
		END CATCH
	COMMIT TRAN
END
