--SP Clientes
use Baseball_Store
GO

CREATE PROCEDURE Altas_Proveedores
    @Nombre varchar(50),
    @ApellidosP varchar(50),
	@ApellidosM varchar(50),
	@Calle nvarchar(40),
	@No_Int int,
	@No_Ext int,
    @CP varchar(5),
	@Descripcion_Asenta varchar(100),
	@Telefono varchar(10)
	AS
BEGIN 
    BEGIN TRAN
  
		INSERT INTO Proveedores(Nombre,ApellidosP, ApellidosM, Calle, No_Int, No_Ext, CP, Id_Asentamiento)
		VALUES (@Nombre, @ApellidosP, @ApellidosM, @Calle, @No_Int, @No_Ext, @CP, (select id_asentamiento from SEPOMEX where cp = @CP and Descripcion_Asentamiento = @Descripcion_Asenta))

		INSERT INTO Telefonos_Proveedores(Telefono,Id_Proveedor)
		VALUES (@Telefono, (select top(1)Id_Proveedor from Proveedores order by 1 desc))

    COMMIT TRAN
END