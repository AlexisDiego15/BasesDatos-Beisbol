CREATE PROCEDURE Baja_Medida_Talla
	@Id_Medidas_Tallas int
	 AS
BEGIN
    BEGIN TRAN
		BEGIN TRY
			IF (SELECT Estatus FROM Medidas_Tallas WHERE Id_Medidas_Tallas = @Id_Medidas_Tallas) = 1
				UPDATE Medidas_Tallas SET Estatus = 0 WHERE Id_Medidas_Tallas = @Id_Medidas_Tallas
			ELSE
				UPDATE Medidas_Tallas SET Estatus = 1 WHERE Id_Medidas_Tallas = @Id_Medidas_Tallas
		END TRY
		BEGIN CATCH
      SELECT 'No se pudo realizar el cambio de estatus del registro' AS msj
			ROLLBACK
		END CATCH
	COMMIT TRAN
END
