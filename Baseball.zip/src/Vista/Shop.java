package Vista;

import Modelo.Cliente;
import Modelo.PresentacionesProducto;
import Modelo.Producto;
import Vista.MotionPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.sql.*;
import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import Vista.ProductoPanel;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
        

/**
 *
 * @author MrJua
 */
public class Shop extends javax.swing.JFrame {
    String user="sa";
    String pass="12345678";
    String database="Baseball_Store";
    String server="DANIEL";
    String url = "jdbc:sqlserver://"+server+";database="+database+";user="+user+";password="+pass+";";
    Cliente currentUser = new Cliente();
    List<ProductoPanel> panels = new ArrayList<>();
    List<ProductoPanel> panelsS = new ArrayList<>();
    List<ProductoPanel> panelsC = new ArrayList<>();
    List<List> productosString = new ArrayList<>();
    List<List> productosBuscarString = new ArrayList<>();
    List<Producto> productos = new ArrayList<>();
    List<Producto> busquedaP = new ArrayList<>();
    List<Producto> kart = new ArrayList<>();
    
    
     /**
     * Creates new form Shop
     */
    public Shop() throws ClassNotFoundException {
        initComponents();
        myComponents();
        cargarProductos();
    }
    
    public Connection Conexion(){
        Connection con = null;
        try{
            DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
            con = DriverManager.getConnection(url);
            if (con != null) {
                DatabaseMetaData dm = (DatabaseMetaData) con.getMetaData();
                System.out.println("Se ha conectado con exito a la DB con los siguientes datos:");
                System.out.println("Driver name: " + dm.getDriverName());
                System.out.println("Driver version: " + dm.getDriverVersion());
                System.out.println("Product name: " + dm.getDatabaseProductName());
                System.out.println("Product version: " + dm.getDatabaseProductVersion());
            }
        }catch(SQLException e){
             e.printStackTrace();
             System.out.println("A ocurrido un error inesperado... o tal vez si lo esperaba(?).");
        }
        
        return con;
    }

    public void myComponents() throws ClassNotFoundException{
        setLocationRelativeTo(null);
        BufferedImage img = null;
            try{
                img = ImageIO.read(getClass().getResource("/Images/icon.png"));
            } catch (IOException e){
                e.printStackTrace();
            }
            Image dimg = img;
            setIconImage(dimg);
    }
    
    public void cargarProductos(){
        Statement prodCall = null;
        Connection conProd = Conexion();
        String sql = "SELECT * FROM vW_Productos_Presentaciones";
        
        try{
            prodCall = conProd.createStatement();
            ResultSet productosQuery = prodCall.executeQuery(sql);
            
            if (productosQuery.next() == false) {
                    System.out.println("Ha ocurrido un error al intentar obtener los Productos");
                    JOptionPane.showMessageDialog(null, "Something's Wrong hommie go check it out");
                } else {
                        List<String> productosRSA = new ArrayList();
                        productosRSA.add("0");
                        productosRSA.add("0");
                        productosRSA.add("AAAAAAAAA");
                        productosRSA.add("0");
                        productosRSA.add("0");
                        productosRSA.add("1");
                        productosRSA.add("AAAAAA");
                        productosRSA.add("AAAAAAA");
                        productosRSA.add("AAAAA");
                        productosRSA.add("AAAAAA");
                        productosRSA.add("AAAAAA");
                        productosRSA.add("0");
                        productosRSA.add("0");
                        productosString.add(productosRSA);
                
                    do { 
                        List<String> productosRS = new ArrayList<>();
                        
                        productosRS.add(productosQuery.getString("Id_Presentacion"));
                        productosRS.add(productosQuery.getString("Id_Productos"));
                        productosRS.add(productosQuery.getString("Nombre_Producto"));
                        productosRS.add(productosQuery.getString("Precio_Venta"));
                        productosRS.add(productosQuery.getString("Precio_Compra"));
                        productosRS.add(productosQuery.getString("Id_Proveedor"));
                        productosRS.add(productosQuery.getString("Categoria"));
                        productosRS.add(productosQuery.getString("Tipo_Producto"));
                        productosRS.add(productosQuery.getString("Medida_Talla"));
                        productosRS.add(productosQuery.getString("Equipo"));
                        productosRS.add(productosQuery.getString("Marca"));
                        productosRS.add(productosQuery.getString("Estatus"));
                        productosRS.add(productosQuery.getString("Existencias"));
                        
                        productosString.add(productosRS);
                    } while (productosQuery.next()); 
                    
                    Collections.sort(productosString, new Sortbynumber());

                    for (int i = 0; i < productosString.size(); i++) {
                        Producto dummy = new Producto();
                        if (i<1){
                            System.out.println("Saltar dummy");
                        }else{
                            if (Integer.parseInt(productosString.get(i).get(1).toString()) != Integer.parseInt(productosString.get(i-1).get(1).toString())) {
                                dummy.setID(Integer.parseInt(productosString.get(i).get(1).toString()));
                                dummy.setId_Provedor(Integer.parseInt(productosString.get(i).get(5).toString()));
                                dummy.setPrecioVenta(Double.parseDouble(productosString.get(i).get(3).toString()));
                                dummy.setPrecioCompra(Double.parseDouble(productosString.get(i).get(4).toString()));
                                dummy.setNombreProducto(productosString.get(i).get(2).toString());
                                dummy.setCategoria(productosString.get(i).get(6).toString());
                                dummy.setTipoProducto(productosString.get(i).get(7).toString());
                                dummy.setEquipo(productosString.get(i).get(9).toString());
                                dummy.setMarca(productosString.get(i).get(10).toString());
                                productos.add(dummy);
                            }
                        }
                    }
                    
                    ProductsGrid.setLayout(new GridLayout(productos.size(), 1, 10, 10));
                    for (int i = 0; i < productos.size(); i++) {
                        List<PresentacionesProducto> presentaciones = new ArrayList<>();
                        for (int j = 0; j < productosString.size(); j++) {
                            if(productos.get(i).getID() == Integer.parseInt(productosString.get(j).get(1).toString())){
                                PresentacionesProducto dummyPres = new PresentacionesProducto();
                                dummyPres.setEstatus(Integer.parseInt(productosString.get(j).get(11).toString()));
                                dummyPres.setExistencias(Integer.parseInt(productosString.get(j).get(12).toString()));
                                dummyPres.setIdProducto(Integer.parseInt(productosString.get(j).get(1).toString()));
                                dummyPres.setIdPresentacion(Integer.parseInt(productosString.get(j).get(0).toString()));
                                dummyPres.setPresentacion(productosString.get(j).get(8).toString());
                                presentaciones.add(dummyPres);
                            }
                        }
                        productos.get(i).setPresentaciones(presentaciones);
                        
                        ProductoPanel panel = new ProductoPanel();
                        panel.ProductoTitle.setText(productos.get(i).getNombreProducto());
                        panel.Precio.setText("$"+productos.get(i).getPrecioVenta().toString());
                        panel.ProductoCat.setText(productos.get(i).getCategoria());
                        panel.ProductEquipo.setText(productos.get(i).getEquipo());
                        panel.ProductType.setText(productos.get(i).getTipoProducto());
                        panel.ProductLabel.setText(productos.get(i).getMarca());
                        panel.Imagen.setIcon(new ImageIcon("../BaseballStoreAdmin/src/Productos/"+productos.get(i).getID()+".jpg"));
                        if(productos.get(i).getPresentaciones().get(productos.get(i).getPresentacionSeleccionada()).getEstatus()<1){
                            panel.AddKart.setIcon(null);
                            
                            panel.NoExistenciasLabel.setText("N/A");
                        }
                        panel.productoAsignado = productos.get(i);
                        System.out.println(panel.productoAsignado.toString());
                        for (int j = 0; j < productos.get(i).getPresentaciones().size(); j++) {
                            panel.Presentaciones.addItem(productos.get(i).getPresentaciones().get(j).getPresentacion());
                        }
                        panels.add(panel);
                        ProductsGrid.add(panel);
                        ProductsGrid.revalidate();
                        ProductsGrid.repaint();
                        pack();
                    }
                }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hubo un error al llamar a la DB");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        CustomStateBar = new MotionPanel(this);
        Name = new javax.swing.JLabel();
        Minimize = new javax.swing.JLabel();
        CloseApp = new javax.swing.JLabel();
        ShopOverview = new javax.swing.JPanel();
        Login = new javax.swing.JPanel();
        PanelEntrada = new javax.swing.JPanel();
        TextoLogin1 = new javax.swing.JLabel();
        TextoPass = new javax.swing.JLabel();
        separadorPassword = new javax.swing.JSeparator();
        TextoUser = new javax.swing.JLabel();
        separadorNombre = new javax.swing.JSeparator();
        BotonLogin = new javax.swing.JButton();
        ErrorPass = new javax.swing.JLabel();
        ErrorName = new javax.swing.JLabel();
        ReturnLogin = new javax.swing.JLabel();
        UserField = new javax.swing.JTextField();
        PassField = new javax.swing.JPasswordField();
        LoginBackGround = new javax.swing.JLabel();
        SignUp = new javax.swing.JPanel();
        PanelRegistro = new javax.swing.JPanel();
        separadorPassR = new javax.swing.JSeparator();
        separadorNombreR = new javax.swing.JSeparator();
        separadorApellidosR = new javax.swing.JSeparator();
        separadorMail = new javax.swing.JSeparator();
        SeparadorUsername = new javax.swing.JSeparator();
        TextoPass2 = new javax.swing.JLabel();
        TextoPass1 = new javax.swing.JLabel();
        TextoRegistro = new javax.swing.JLabel();
        TextoPass3 = new javax.swing.JLabel();
        TextoPass4 = new javax.swing.JLabel();
        TextoTel = new javax.swing.JLabel();
        UserReg = new javax.swing.JTextField();
        NombreReg = new javax.swing.JTextField();
        ApellidosRegM = new javax.swing.JTextField();
        MailReg = new javax.swing.JTextField();
        BotonRegistrar = new javax.swing.JButton();
        ErrorRegN = new javax.swing.JLabel();
        ErrorRegPass = new javax.swing.JLabel();
        ErrorRegU = new javax.swing.JLabel();
        ErrorRegC = new javax.swing.JLabel();
        ErrorRegA = new javax.swing.JLabel();
        PassReg = new javax.swing.JTextField();
        RegresarSignUp = new javax.swing.JLabel();
        ApellidosRegP = new javax.swing.JTextField();
        separadorApellidosRP = new javax.swing.JSeparator();
        TextoPass6 = new javax.swing.JLabel();
        PhoneReg = new javax.swing.JTextField();
        SeparadorUsername1 = new javax.swing.JSeparator();
        FondoRegistrar = new javax.swing.JLabel();
        EditProfile = new javax.swing.JPanel();
        EditPanel = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        EApellidoM = new javax.swing.JTextField();
        EPhone = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        EMail = new javax.swing.JTextField();
        EApellidoP = new javax.swing.JTextField();
        ENombre = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        EUsername = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        ECP = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        ENoInt = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        EPass = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        ENoExt = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        ECalle = new javax.swing.JTextField();
        ConfirmEdit = new javax.swing.JButton();
        CancelEdit = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        ETA = new javax.swing.JTextField();
        FondoEdit = new javax.swing.JLabel();
        Historial = new javax.swing.JPanel();
        Categeorias1 = new javax.swing.JPanel();
        RegresarHistorial = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        HistorialTabla = new javax.swing.JTable();
        FondoVenta3 = new javax.swing.JLabel();
        CarroCompras = new javax.swing.JPanel();
        SearchTV1 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        RegresarCarro = new javax.swing.JLabel();
        ScrollCarroCompras = new javax.swing.JScrollPane();
        CarroGrid = new javax.swing.JPanel();
        SearchTV2 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        VaciarCarro = new javax.swing.JButton();
        TotalProdsCarro = new javax.swing.JLabel();
        EliminarElementoCarro = new javax.swing.JButton();
        PreceedtoBuy = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        IDVaciar = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        TotalPrecioCarro = new javax.swing.JLabel();
        FondoVenta2 = new javax.swing.JLabel();
        ProductsSearchResult = new javax.swing.JPanel();
        SearchTV = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        RegresarSearch = new javax.swing.JLabel();
        ScrollSearch = new javax.swing.JScrollPane();
        BusquedaGrid = new javax.swing.JPanel();
        FondoVenta1 = new javax.swing.JLabel();
        ProductsOverview = new javax.swing.JPanel();
        Categeorias = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        SrollPO = new javax.swing.JScrollPane();
        ProductsGrid = new javax.swing.JPanel();
        FondoVenta = new javax.swing.JLabel();
        Toolbar = new javax.swing.JPanel();
        SearchKart = new javax.swing.JPanel();
        SearchIcon = new javax.swing.JLabel();
        SearchBar = new javax.swing.JSeparator();
        SearchProduct = new javax.swing.JTextField();
        Buscar = new javax.swing.JLabel();
        CarritoCompras = new javax.swing.JLabel();
        SesionOptions = new javax.swing.JPanel();
        WelcomeUserText = new javax.swing.JLabel();
        CerrarSesion = new javax.swing.JLabel();
        Configuracion = new javax.swing.JLabel();
        HistorialCompras = new javax.swing.JLabel();
        NoSesionOptions = new javax.swing.JPanel();
        SignUpIcon = new javax.swing.JLabel();
        LoginIcon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Baseball Store");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setMaximumSize(new java.awt.Dimension(1920, 1080));
        setMinimumSize(new java.awt.Dimension(1280, 720));
        setName("PrincipalFrame"); // NOI18N
        setUndecorated(true);
        setPreferredSize(new java.awt.Dimension(1280, 720));
        setResizable(false);
        getContentPane().setLayout(new java.awt.BorderLayout());

        Footer.setBackground(new java.awt.Color(211, 24, 28));
        Footer.setPreferredSize(new java.awt.Dimension(1280, 30));
        Footer.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Montserrat ExtraBold", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BaseballStore");
        Footer.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 240, 30));

        jLabel2.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("© BaseballStore by NSFW. C'mon Catch some goods.");
        Footer.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 0, -1, 30));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/facebook.png"))); // NOI18N
        Footer.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 0, -1, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/twitter.png"))); // NOI18N
        Footer.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 0, -1, 30));

        getContentPane().add(Footer, java.awt.BorderLayout.PAGE_END);

        CustomStateBar.setBackground(new java.awt.Color(211, 24, 28));
        CustomStateBar.setPreferredSize(new java.awt.Dimension(1280, 25));
        CustomStateBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Name.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        Name.setForeground(new java.awt.Color(255, 255, 255));
        Name.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/icon.png"))); // NOI18N
        Name.setText("BaseballStore");
        CustomStateBar.add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        Minimize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_minimize_white_24dp.png"))); // NOI18N
        Minimize.setToolTipText("Minimizar");
        Minimize.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Minimize.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MinimizeMouseClicked(evt);
            }
        });
        CustomStateBar.add(Minimize, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 0, -1, -1));

        CloseApp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_close_white_24dp.png"))); // NOI18N
        CloseApp.setToolTipText("Cerrar Aplicacion");
        CloseApp.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        CloseApp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CloseAppMouseClicked(evt);
            }
        });
        CustomStateBar.add(CloseApp, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 0, -1, -1));

        getContentPane().add(CustomStateBar, java.awt.BorderLayout.PAGE_START);

        ShopOverview.setLayout(new java.awt.BorderLayout());

        Login.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelEntrada.setBackground(new java.awt.Color(0, 0, 136));
        PanelEntrada.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TextoLogin1.setFont(new java.awt.Font("Montserrat", 1, 48)); // NOI18N
        TextoLogin1.setForeground(new java.awt.Color(255, 255, 255));
        TextoLogin1.setText("Inicia Sesion");
        PanelEntrada.add(TextoLogin1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, -1, -1));

        TextoPass.setFont(new java.awt.Font("Montserrat", 0, 28)); // NOI18N
        TextoPass.setForeground(new java.awt.Color(255, 255, 255));
        TextoPass.setText("Contraseña:");
        PanelEntrada.add(TextoPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, -1, -1));

        separadorPassword.setForeground(new java.awt.Color(255, 255, 255));
        separadorPassword.setOpaque(true);
        PanelEntrada.add(separadorPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 390, 420, -1));

        TextoUser.setFont(new java.awt.Font("Montserrat", 0, 28)); // NOI18N
        TextoUser.setForeground(new java.awt.Color(255, 255, 255));
        TextoUser.setText("Nombre de Usuario:");
        PanelEntrada.add(TextoUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, -1, -1));

        separadorNombre.setForeground(new java.awt.Color(255, 255, 255));
        separadorNombre.setOpaque(true);
        PanelEntrada.add(separadorNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 228, 420, -1));

        BotonLogin.setBackground(new java.awt.Color(211, 24, 28));
        BotonLogin.setFont(new java.awt.Font("Montserrat Alternates", 1, 24)); // NOI18N
        BotonLogin.setForeground(new java.awt.Color(255, 255, 255));
        BotonLogin.setText("Acceder");
        BotonLogin.setBorder(null);
        BotonLogin.setBorderPainted(false);
        BotonLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        BotonLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonLoginMouseClicked(evt);
            }
        });
        PanelEntrada.add(BotonLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 450, 420, 40));

        ErrorPass.setBackground(new java.awt.Color(239, 83, 80));
        ErrorPass.setFont(new java.awt.Font("Noto Sans", 1, 12)); // NOI18N
        ErrorPass.setForeground(new java.awt.Color(239, 83, 80));
        PanelEntrada.add(ErrorPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 390, 70, 10));

        ErrorName.setBackground(new java.awt.Color(239, 83, 80));
        ErrorName.setFont(new java.awt.Font("Noto Sans", 1, 12)); // NOI18N
        ErrorName.setForeground(new java.awt.Color(239, 83, 80));
        PanelEntrada.add(ErrorName, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, 60, 10));

        ReturnLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_keyboard_backspace_white_36dp.png"))); // NOI18N
        ReturnLogin.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ReturnLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ReturnLoginMouseClicked(evt);
            }
        });
        PanelEntrada.add(ReturnLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        UserField.setBackground(new java.awt.Color(0, 0, 136));
        UserField.setFont(new java.awt.Font("Montserrat", 0, 24)); // NOI18N
        UserField.setForeground(new java.awt.Color(255, 255, 255));
        UserField.setBorder(null);
        PanelEntrada.add(UserField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 420, 40));

        PassField.setBackground(new java.awt.Color(0, 0, 136));
        PassField.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        PassField.setForeground(new java.awt.Color(255, 255, 255));
        PassField.setBorder(null);
        PanelEntrada.add(PassField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, 420, 40));

        Login.add(PanelEntrada, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 650));

        LoginBackGround.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LoginBackGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fondo1.jpg"))); // NOI18N
        Login.add(LoginBackGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 650));

        ShopOverview.add(Login, java.awt.BorderLayout.CENTER);

        SignUp.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelRegistro.setBackground(new java.awt.Color(0, 0, 136));
        PanelRegistro.setForeground(new java.awt.Color(33, 150, 243));
        PanelRegistro.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        separadorPassR.setBackground(new java.awt.Color(33, 150, 243));
        separadorPassR.setForeground(new java.awt.Color(255, 255, 255));
        PanelRegistro.add(separadorPassR, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 540, 420, 10));

        separadorNombreR.setBackground(new java.awt.Color(33, 150, 243));
        separadorNombreR.setForeground(new java.awt.Color(255, 255, 255));
        PanelRegistro.add(separadorNombreR, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, 420, 10));

        separadorApellidosR.setBackground(new java.awt.Color(33, 150, 243));
        separadorApellidosR.setForeground(new java.awt.Color(255, 255, 255));
        PanelRegistro.add(separadorApellidosR, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 240, 200, 10));

        separadorMail.setBackground(new java.awt.Color(33, 150, 243));
        separadorMail.setForeground(new java.awt.Color(255, 255, 255));
        PanelRegistro.add(separadorMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 340, 420, 10));

        SeparadorUsername.setBackground(new java.awt.Color(33, 150, 243));
        SeparadorUsername.setForeground(new java.awt.Color(255, 255, 255));
        PanelRegistro.add(SeparadorUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 440, 210, 10));

        TextoPass2.setFont(new java.awt.Font("Montserrat", 0, 28)); // NOI18N
        TextoPass2.setForeground(new java.awt.Color(255, 255, 255));
        TextoPass2.setText("Nombre:");
        PanelRegistro.add(TextoPass2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, -1, -1));

        TextoPass1.setFont(new java.awt.Font("Montserrat", 0, 28)); // NOI18N
        TextoPass1.setForeground(new java.awt.Color(255, 255, 255));
        TextoPass1.setText("Contraseña:");
        PanelRegistro.add(TextoPass1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, -1, -1));

        TextoRegistro.setFont(new java.awt.Font("Montserrat", 1, 48)); // NOI18N
        TextoRegistro.setForeground(new java.awt.Color(255, 255, 255));
        TextoRegistro.setText("Registrate");
        PanelRegistro.add(TextoRegistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, -1, -1));

        TextoPass3.setFont(new java.awt.Font("Montserrat", 0, 28)); // NOI18N
        TextoPass3.setForeground(new java.awt.Color(255, 255, 255));
        TextoPass3.setText("Apellidos:");
        PanelRegistro.add(TextoPass3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, -1, -1));

        TextoPass4.setFont(new java.awt.Font("Montserrat", 0, 28)); // NOI18N
        TextoPass4.setForeground(new java.awt.Color(255, 255, 255));
        TextoPass4.setText("Correo:");
        PanelRegistro.add(TextoPass4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 270, -1, -1));

        TextoTel.setFont(new java.awt.Font("Montserrat", 0, 28)); // NOI18N
        TextoTel.setForeground(new java.awt.Color(255, 255, 255));
        TextoTel.setText("Telefono:");
        PanelRegistro.add(TextoTel, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 370, -1, -1));

        UserReg.setBackground(new java.awt.Color(0, 0, 136));
        UserReg.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        UserReg.setForeground(new java.awt.Color(255, 255, 255));
        UserReg.setBorder(null);
        UserReg.setCaretColor(new java.awt.Color(255, 255, 255));
        UserReg.setOpaque(false);
        PanelRegistro.add(UserReg, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 410, 210, 30));

        NombreReg.setBackground(new java.awt.Color(0, 0, 136));
        NombreReg.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        NombreReg.setForeground(new java.awt.Color(255, 255, 255));
        NombreReg.setBorder(null);
        NombreReg.setCaretColor(new java.awt.Color(255, 255, 255));
        NombreReg.setOpaque(false);
        PanelRegistro.add(NombreReg, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 420, 30));

        ApellidosRegM.setBackground(new java.awt.Color(0, 0, 136));
        ApellidosRegM.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        ApellidosRegM.setForeground(new java.awt.Color(255, 255, 255));
        ApellidosRegM.setBorder(null);
        ApellidosRegM.setCaretColor(new java.awt.Color(255, 255, 255));
        ApellidosRegM.setOpaque(false);
        PanelRegistro.add(ApellidosRegM, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, 200, 30));

        MailReg.setBackground(new java.awt.Color(0, 0, 136));
        MailReg.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        MailReg.setForeground(new java.awt.Color(255, 255, 255));
        MailReg.setBorder(null);
        MailReg.setCaretColor(new java.awt.Color(255, 255, 255));
        MailReg.setOpaque(false);
        PanelRegistro.add(MailReg, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 310, 420, 30));

        BotonRegistrar.setBackground(new java.awt.Color(211, 24, 28));
        BotonRegistrar.setFont(new java.awt.Font("Montserrat Alternates", 1, 24)); // NOI18N
        BotonRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        BotonRegistrar.setText("Registrar");
        BotonRegistrar.setBorder(null);
        BotonRegistrar.setBorderPainted(false);
        BotonRegistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        BotonRegistrar.setFocusable(false);
        BotonRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegistrarMouseClicked(evt);
            }
        });
        PanelRegistro.add(BotonRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 560, 420, 40));

        ErrorRegN.setForeground(new java.awt.Color(239, 83, 80));
        PanelRegistro.add(ErrorRegN, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 150, 140, -1));

        ErrorRegPass.setForeground(new java.awt.Color(239, 83, 80));
        PanelRegistro.add(ErrorRegPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 550, 160, 10));

        ErrorRegU.setForeground(new java.awt.Color(239, 83, 80));
        PanelRegistro.add(ErrorRegU, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 450, 160, -1));

        ErrorRegC.setForeground(new java.awt.Color(239, 83, 80));
        PanelRegistro.add(ErrorRegC, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 350, 190, -1));

        ErrorRegA.setForeground(new java.awt.Color(239, 83, 80));
        PanelRegistro.add(ErrorRegA, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 170, -1));

        PassReg.setBackground(new java.awt.Color(0, 0, 136));
        PassReg.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        PassReg.setForeground(new java.awt.Color(255, 255, 255));
        PassReg.setBorder(null);
        PanelRegistro.add(PassReg, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 510, 420, 30));

        RegresarSignUp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_keyboard_backspace_white_36dp.png"))); // NOI18N
        RegresarSignUp.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        RegresarSignUp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RegresarSignUpMouseClicked(evt);
            }
        });
        PanelRegistro.add(RegresarSignUp, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));

        ApellidosRegP.setBackground(new java.awt.Color(0, 0, 136));
        ApellidosRegP.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        ApellidosRegP.setForeground(new java.awt.Color(255, 255, 255));
        ApellidosRegP.setBorder(null);
        ApellidosRegP.setCaretColor(new java.awt.Color(255, 255, 255));
        ApellidosRegP.setOpaque(false);
        PanelRegistro.add(ApellidosRegP, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 210, 200, 30));

        separadorApellidosRP.setBackground(new java.awt.Color(33, 150, 243));
        separadorApellidosRP.setForeground(new java.awt.Color(255, 255, 255));
        PanelRegistro.add(separadorApellidosRP, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, 200, 10));

        TextoPass6.setFont(new java.awt.Font("Montserrat", 0, 28)); // NOI18N
        TextoPass6.setForeground(new java.awt.Color(255, 255, 255));
        TextoPass6.setText("Username:");
        PanelRegistro.add(TextoPass6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 370, -1, -1));

        PhoneReg.setBackground(new java.awt.Color(0, 0, 136));
        PhoneReg.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        PhoneReg.setForeground(new java.awt.Color(255, 255, 255));
        PhoneReg.setBorder(null);
        PhoneReg.setCaretColor(new java.awt.Color(255, 255, 255));
        PhoneReg.setOpaque(false);
        PanelRegistro.add(PhoneReg, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 410, 210, 30));

        SeparadorUsername1.setBackground(new java.awt.Color(33, 150, 243));
        SeparadorUsername1.setForeground(new java.awt.Color(255, 255, 255));
        PanelRegistro.add(SeparadorUsername1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 440, 210, 10));

        SignUp.add(PanelRegistro, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 650));

        FondoRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fondo2.jpg"))); // NOI18N
        SignUp.add(FondoRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 650));

        ShopOverview.add(SignUp, java.awt.BorderLayout.CENTER);

        EditProfile.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        EditPanel.setBackground(new java.awt.Color(0, 0, 136));
        EditPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Montserrat", 0, 16)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Direccion:");
        EditPanel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, -1, -1));

        jLabel6.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Telefono:");
        EditPanel.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, -1, -1));

        jLabel7.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Nombre:");
        EditPanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, -1, -1));

        EApellidoM.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        EApellidoM.setForeground(new java.awt.Color(255, 255, 255));
        EApellidoM.setOpaque(false);
        EditPanel.add(EApellidoM, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 170, -1));

        EPhone.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        EPhone.setForeground(new java.awt.Color(255, 255, 255));
        EPhone.setOpaque(false);
        EditPanel.add(EPhone, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 190, 190, -1));

        jLabel8.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Apellidos:");
        EditPanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 50, -1, -1));

        jLabel9.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Username:");
        EditPanel.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        EMail.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        EMail.setForeground(new java.awt.Color(255, 255, 255));
        EMail.setOpaque(false);
        EditPanel.add(EMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 130, 190, -1));

        EApellidoP.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        EApellidoP.setForeground(new java.awt.Color(255, 255, 255));
        EApellidoP.setOpaque(false);
        EditPanel.add(EApellidoP, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 70, 170, -1));

        ENombre.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        ENombre.setForeground(new java.awt.Color(255, 255, 255));
        ENombre.setOpaque(false);
        EditPanel.add(ENombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 190, -1));

        jLabel10.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("No. Int");
        EditPanel.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, -1, -1));

        EUsername.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        EUsername.setForeground(new java.awt.Color(255, 255, 255));
        EUsername.setOpaque(false);
        EditPanel.add(EUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 190, -1));

        jLabel11.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Colonia:");
        EditPanel.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 310, -1, -1));

        ECP.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        ECP.setForeground(new java.awt.Color(255, 255, 255));
        ECP.setOpaque(false);
        EditPanel.add(ECP, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 280, 100, -1));

        jLabel12.setFont(new java.awt.Font("Montserrat", 0, 20)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Editar Perfil");
        EditPanel.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        jLabel13.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Contraseña:");
        EditPanel.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, -1, -1));

        ENoInt.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        ENoInt.setForeground(new java.awt.Color(255, 255, 255));
        ENoInt.setOpaque(false);
        EditPanel.add(ENoInt, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 280, 80, -1));

        jLabel14.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Correo:");
        EditPanel.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 110, -1, -1));

        EPass.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        EPass.setForeground(new java.awt.Color(255, 255, 255));
        EPass.setOpaque(false);
        EditPanel.add(EPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, 260, -1));

        jLabel15.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("No. Ext");
        EditPanel.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 260, -1, -1));

        ENoExt.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        ENoExt.setForeground(new java.awt.Color(255, 255, 255));
        ENoExt.setOpaque(false);
        EditPanel.add(ENoExt, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 280, 80, -1));

        jLabel16.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Calle:");
        EditPanel.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, -1, -1));

        ECalle.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        ECalle.setForeground(new java.awt.Color(255, 255, 255));
        ECalle.setOpaque(false);
        EditPanel.add(ECalle, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 270, -1));

        ConfirmEdit.setBackground(new java.awt.Color(211, 24, 28));
        ConfirmEdit.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        ConfirmEdit.setForeground(new java.awt.Color(255, 255, 255));
        ConfirmEdit.setText("Confimar Cambios");
        ConfirmEdit.setBorder(null);
        ConfirmEdit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ConfirmEditMouseClicked(evt);
            }
        });
        EditPanel.add(ConfirmEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 410, 270, 50));

        CancelEdit.setBackground(new java.awt.Color(211, 24, 28));
        CancelEdit.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        CancelEdit.setForeground(new java.awt.Color(255, 255, 255));
        CancelEdit.setText("Volver");
        CancelEdit.setBorder(null);
        CancelEdit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CancelEditMouseClicked(evt);
            }
        });
        EditPanel.add(CancelEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 410, 270, 50));

        jLabel17.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Codigo Postal");
        EditPanel.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 260, -1, -1));

        ETA.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        ETA.setForeground(new java.awt.Color(255, 255, 255));
        ETA.setOpaque(false);
        EditPanel.add(ETA, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 330, 200, -1));

        EditProfile.add(EditPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 620));

        FondoEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fondo3.jpg"))); // NOI18N
        EditProfile.add(FondoEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 620));

        ShopOverview.add(EditProfile, java.awt.BorderLayout.CENTER);

        Historial.setBackground(new java.awt.Color(255, 255, 255));
        Historial.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Categeorias1.setBackground(new java.awt.Color(102, 153, 255));
        Categeorias1.setPreferredSize(new java.awt.Dimension(1150, 100));
        Categeorias1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        RegresarHistorial.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        RegresarHistorial.setForeground(new java.awt.Color(255, 255, 255));
        RegresarHistorial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_keyboard_backspace_white_36dp.png"))); // NOI18N
        RegresarHistorial.setText("Regrersar");
        RegresarHistorial.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        RegresarHistorial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RegresarHistorialMouseClicked(evt);
            }
        });
        Categeorias1.add(RegresarHistorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel21.setFont(new java.awt.Font("Montserrat", 0, 48)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("Historial de Compras");
        Categeorias1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 660, 60));

        Historial.add(Categeorias1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 1170, 60));

        jScrollPane1.setBorder(null);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        HistorialTabla.setBackground(new java.awt.Color(102, 153, 255));
        HistorialTabla.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        HistorialTabla.setForeground(new java.awt.Color(255, 255, 255));
        HistorialTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        HistorialTabla.setSelectionBackground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(HistorialTabla);

        Historial.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 1110, 560));

        FondoVenta3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fondo4.jpg"))); // NOI18N
        Historial.add(FondoVenta3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 620));

        ShopOverview.add(Historial, java.awt.BorderLayout.CENTER);

        CarroCompras.setBackground(new java.awt.Color(255, 255, 255));
        CarroCompras.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SearchTV1.setBackground(new java.awt.Color(102, 153, 255));
        SearchTV1.setPreferredSize(new java.awt.Dimension(1150, 100));
        SearchTV1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel29.setFont(new java.awt.Font("Montserrat", 0, 36)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Checkout");
        SearchTV1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 0, -1, 60));

        RegresarCarro.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        RegresarCarro.setForeground(new java.awt.Color(255, 255, 255));
        RegresarCarro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_keyboard_backspace_white_36dp.png"))); // NOI18N
        RegresarCarro.setText("Regresar");
        RegresarCarro.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        RegresarCarro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RegresarCarroMouseClicked(evt);
            }
        });
        SearchTV1.add(RegresarCarro, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, 60));

        CarroCompras.add(SearchTV1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 1170, 60));

        ScrollCarroCompras.setBackground(new java.awt.Color(255, 255, 255));
        ScrollCarroCompras.setBorder(null);
        ScrollCarroCompras.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        ScrollCarroCompras.setViewportBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        ScrollCarroCompras.setPreferredSize(new java.awt.Dimension(1200, 100));

        CarroGrid.setBackground(new java.awt.Color(0, 0, 136));

        javax.swing.GroupLayout CarroGridLayout = new javax.swing.GroupLayout(CarroGrid);
        CarroGrid.setLayout(CarroGridLayout);
        CarroGridLayout.setHorizontalGroup(
            CarroGridLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1200, Short.MAX_VALUE)
        );
        CarroGridLayout.setVerticalGroup(
            CarroGridLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 570, Short.MAX_VALUE)
        );

        ScrollCarroCompras.setViewportView(CarroGrid);

        CarroCompras.add(ScrollCarroCompras, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 1210, 500));

        SearchTV2.setBackground(new java.awt.Color(102, 153, 255));
        SearchTV2.setPreferredSize(new java.awt.Dimension(1150, 100));
        SearchTV2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Total de Productos:");
        SearchTV2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, -2, -1, 60));

        VaciarCarro.setBackground(new java.awt.Color(211, 24, 28));
        VaciarCarro.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        VaciarCarro.setText("Vaciar Carrito");
        VaciarCarro.setOpaque(false);
        VaciarCarro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VaciarCarroMouseClicked(evt);
            }
        });
        SearchTV2.add(VaciarCarro, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 180, 40));

        TotalProdsCarro.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        TotalProdsCarro.setForeground(new java.awt.Color(255, 255, 255));
        TotalProdsCarro.setText("###");
        SearchTV2.add(TotalProdsCarro, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 0, -1, 60));

        EliminarElementoCarro.setBackground(new java.awt.Color(211, 24, 28));
        EliminarElementoCarro.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        EliminarElementoCarro.setText("Eliminar Elemento");
        EliminarElementoCarro.setOpaque(false);
        EliminarElementoCarro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EliminarElementoCarroMouseClicked(evt);
            }
        });
        SearchTV2.add(EliminarElementoCarro, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 10, 150, 40));

        PreceedtoBuy.setBackground(new java.awt.Color(211, 24, 28));
        PreceedtoBuy.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        PreceedtoBuy.setText("Comprar");
        PreceedtoBuy.setOpaque(false);
        PreceedtoBuy.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PreceedtoBuyMouseClicked(evt);
            }
        });
        SearchTV2.add(PreceedtoBuy, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 10, 160, 40));
        SearchTV2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 40, 130, 20));

        IDVaciar.setBackground(new java.awt.Color(102, 153, 255));
        IDVaciar.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        IDVaciar.setForeground(new java.awt.Color(255, 255, 255));
        SearchTV2.add(IDVaciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 130, 30));

        jLabel20.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Total a Pagar:");
        SearchTV2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 0, -1, 60));

        TotalPrecioCarro.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        TotalPrecioCarro.setForeground(new java.awt.Color(255, 255, 255));
        TotalPrecioCarro.setText("$$$$");
        SearchTV2.add(TotalPrecioCarro, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 0, -1, 60));

        CarroCompras.add(SearchTV2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 560, 1170, 60));

        FondoVenta2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fondo4.jpg"))); // NOI18N
        CarroCompras.add(FondoVenta2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 620));

        ShopOverview.add(CarroCompras, java.awt.BorderLayout.CENTER);

        ProductsSearchResult.setBackground(new java.awt.Color(0, 0, 136));
        ProductsSearchResult.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SearchTV.setBackground(new java.awt.Color(102, 153, 255));
        SearchTV.setPreferredSize(new java.awt.Dimension(1150, 100));
        SearchTV.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel28.setFont(new java.awt.Font("Montserrat", 0, 36)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Resultados de la Busqueda");
        SearchTV.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 0, -1, 60));

        RegresarSearch.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        RegresarSearch.setForeground(new java.awt.Color(255, 255, 255));
        RegresarSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_keyboard_backspace_white_36dp.png"))); // NOI18N
        RegresarSearch.setText("Regresar");
        RegresarSearch.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        RegresarSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RegresarSearchMouseClicked(evt);
            }
        });
        SearchTV.add(RegresarSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, 60));

        ProductsSearchResult.add(SearchTV, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 1170, 60));

        ScrollSearch.setBackground(new java.awt.Color(255, 255, 255));
        ScrollSearch.setBorder(null);
        ScrollSearch.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        ScrollSearch.setViewportBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        ScrollSearch.setPreferredSize(new java.awt.Dimension(1200, 100));

        BusquedaGrid.setBackground(new java.awt.Color(0, 0, 136));

        javax.swing.GroupLayout BusquedaGridLayout = new javax.swing.GroupLayout(BusquedaGrid);
        BusquedaGrid.setLayout(BusquedaGridLayout);
        BusquedaGridLayout.setHorizontalGroup(
            BusquedaGridLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1200, Short.MAX_VALUE)
        );
        BusquedaGridLayout.setVerticalGroup(
            BusquedaGridLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 570, Short.MAX_VALUE)
        );

        ScrollSearch.setViewportView(BusquedaGrid);

        ProductsSearchResult.add(ScrollSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 1210, 560));

        FondoVenta1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fondo4.jpg"))); // NOI18N
        ProductsSearchResult.add(FondoVenta1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 620));

        ShopOverview.add(ProductsSearchResult, java.awt.BorderLayout.CENTER);

        ProductsOverview.setBackground(new java.awt.Color(255, 255, 255));
        ProductsOverview.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Categeorias.setBackground(new java.awt.Color(102, 153, 255));
        Categeorias.setPreferredSize(new java.awt.Dimension(1150, 100));
        Categeorias.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setFont(new java.awt.Font("Montserrat", 0, 48)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("Baseball Store");
        Categeorias.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 0, 420, 60));

        ProductsOverview.add(Categeorias, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 1170, 60));

        SrollPO.setBackground(new java.awt.Color(255, 255, 255));
        SrollPO.setBorder(null);
        SrollPO.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SrollPO.setViewportBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        SrollPO.setPreferredSize(new java.awt.Dimension(1200, 100));

        ProductsGrid.setBackground(new java.awt.Color(0, 0, 136));

        javax.swing.GroupLayout ProductsGridLayout = new javax.swing.GroupLayout(ProductsGrid);
        ProductsGrid.setLayout(ProductsGridLayout);
        ProductsGridLayout.setHorizontalGroup(
            ProductsGridLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1200, Short.MAX_VALUE)
        );
        ProductsGridLayout.setVerticalGroup(
            ProductsGridLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 570, Short.MAX_VALUE)
        );

        SrollPO.setViewportView(ProductsGrid);

        ProductsOverview.add(SrollPO, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 1210, 560));

        FondoVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/fondo4.jpg"))); // NOI18N
        ProductsOverview.add(FondoVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 620));

        ShopOverview.add(ProductsOverview, java.awt.BorderLayout.CENTER);

        Toolbar.setBackground(new java.awt.Color(0, 0, 136));
        Toolbar.setPreferredSize(new java.awt.Dimension(1280, 50));
        Toolbar.setLayout(new java.awt.BorderLayout());

        SearchKart.setBackground(new java.awt.Color(0, 0, 136));
        SearchKart.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SearchIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_search_white_36dp.png"))); // NOI18N
        SearchKart.add(SearchIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, 50));
        SearchKart.add(SearchBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 250, 10));

        SearchProduct.setBackground(new java.awt.Color(0, 0, 136));
        SearchProduct.setFont(new java.awt.Font("Montserrat", 0, 12)); // NOI18N
        SearchProduct.setForeground(new java.awt.Color(255, 255, 255));
        SearchProduct.setText("Busca un producto...");
        SearchProduct.setBorder(null);
        SearchKart.add(SearchProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, 250, 30));

        Buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_send_white_36dp.png"))); // NOI18N
        Buscar.setToolTipText("Buscar!");
        Buscar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Buscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BuscarMouseClicked(evt);
            }
        });
        SearchKart.add(Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 0, -1, 50));

        CarritoCompras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_shopping_cart_white_36dp.png"))); // NOI18N
        CarritoCompras.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        CarritoCompras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CarritoComprasMouseClicked(evt);
            }
        });
        SearchKart.add(CarritoCompras, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 40, 50));

        Toolbar.add(SearchKart, java.awt.BorderLayout.WEST);

        SesionOptions.setBackground(new java.awt.Color(0, 0, 136));
        SesionOptions.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        WelcomeUserText.setFont(new java.awt.Font("Montserrat", 0, 18)); // NOI18N
        WelcomeUserText.setForeground(new java.awt.Color(255, 255, 255));
        WelcomeUserText.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        WelcomeUserText.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        SesionOptions.add(WelcomeUserText, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 0, 310, 50));

        CerrarSesion.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        CerrarSesion.setForeground(new java.awt.Color(255, 255, 255));
        CerrarSesion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_exit_to_app_white_36dp.png"))); // NOI18N
        CerrarSesion.setText("Salir");
        CerrarSesion.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        CerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CerrarSesionMouseClicked(evt);
            }
        });
        SesionOptions.add(CerrarSesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 0, 80, 50));

        Configuracion.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        Configuracion.setForeground(new java.awt.Color(255, 255, 255));
        Configuracion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_miscellaneous_services_white_36dp.png"))); // NOI18N
        Configuracion.setText("Configuracion");
        Configuracion.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Configuracion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ConfiguracionMouseClicked(evt);
            }
        });
        SesionOptions.add(Configuracion, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 0, -1, 50));

        HistorialCompras.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        HistorialCompras.setForeground(new java.awt.Color(255, 255, 255));
        HistorialCompras.setText("Historial de Compras");
        HistorialCompras.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        HistorialCompras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HistorialComprasMouseClicked(evt);
            }
        });
        SesionOptions.add(HistorialCompras, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 0, -1, 50));

        Toolbar.add(SesionOptions, java.awt.BorderLayout.EAST);

        NoSesionOptions.setBackground(new java.awt.Color(0, 0, 136));
        NoSesionOptions.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SignUpIcon.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        SignUpIcon.setForeground(new java.awt.Color(255, 255, 255));
        SignUpIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_person_add_white_24dp.png"))); // NOI18N
        SignUpIcon.setText("Registrate    ");
        SignUpIcon.setToolTipText("Registrarse!");
        SignUpIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        SignUpIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SignUpIconMouseClicked(evt);
            }
        });
        NoSesionOptions.add(SignUpIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 0, -1, -1));

        LoginIcon.setFont(new java.awt.Font("Montserrat", 0, 14)); // NOI18N
        LoginIcon.setForeground(new java.awt.Color(255, 255, 255));
        LoginIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/baseline_person_white_24dp.png"))); // NOI18N
        LoginIcon.setText("Inicia Sesion   ");
        LoginIcon.setToolTipText("Iniciar Sesion");
        LoginIcon.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        LoginIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LoginIconMouseClicked(evt);
            }
        });
        NoSesionOptions.add(LoginIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 0, -1, -1));

        Toolbar.add(NoSesionOptions, java.awt.BorderLayout.EAST);

        ShopOverview.add(Toolbar, java.awt.BorderLayout.PAGE_START);

        getContentPane().add(ShopOverview, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MinimizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MinimizeMouseClicked
        // TODO add your handling code here:
        this.setState(Frame.ICONIFIED);
    }//GEN-LAST:event_MinimizeMouseClicked

    private void CloseAppMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CloseAppMouseClicked
        // TODO add your handling code here:
        this.processWindowEvent(
                new WindowEvent(
                      this, WindowEvent.WINDOW_CLOSING));
    }//GEN-LAST:event_CloseAppMouseClicked

    private void BotonLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonLoginMouseClicked
        if(PassField.getPassword().length == 0){
            separadorPassword.setBackground(new Color(239,83,80));
            separadorPassword.setForeground(new Color(239,83,80));
            ErrorPass.setText("Ingresa una Contraseña...");
        }else
        if(UserField.getText().equals("")){
            separadorNombre.setBackground(new Color(239,83,80));
            separadorNombre.setForeground(new Color(239,83,80));
            ErrorName.setText("Ingresa tu Username...");
        }else{
            Statement busquedaUser = null;
            Connection conLogin = Conexion();
            String sql = "SELECT * FROM Clientes WHERE Nombre_Usuario='"+UserField.getText()+"' AND Contrasena='"+PassField.getText()+"'";
            
            try{
                busquedaUser = conLogin.createStatement();
                ResultSet usuario = busquedaUser.executeQuery(sql);

                if (usuario.next() == false) {
                    System.out.println("Ha ocurrido un error al intentar iniciar sesion");
                    JOptionPane.showMessageDialog(null, "Al parecer tus datos son incorrectos... intenta de nuevo");
                } else { 
                    do { 
                        currentUser.setNombre(usuario.getString("Nombre"));
                        currentUser.setApellidoPaterno(usuario.getString("Apellidos_Paterno"));
                        currentUser.setApellidoMaterno(usuario.getString("Apellidos_Materno"));
                        currentUser.setUsername(usuario.getString("Nombre_Usuario"));
                        currentUser.setEmail(usuario.getString("Email"));
                        currentUser.setContraseña(usuario.getString("Contrasena"));
                        currentUser.setTelefono(usuario.getString("Telefono"));
                        currentUser.setCalle(usuario.getString("Calle"));
                        currentUser.setNo_Ext(usuario.getInt("No_Ext"));
                        currentUser.setNo_Int(usuario.getInt("No_Int"));
                        currentUser.setCP(usuario.getString("CP"));
                        currentUser.setID(usuario.getInt("Id_Cliente"));
                        currentUser.setID_Asentamiento(usuario.getString("Id_Asentamiento"));
                        System.out.println("Se ha loggeado con exito a:"+currentUser.toString());
                        ShopOverview.remove(Login);
                        ShopOverview.repaint();
                        ShopOverview.revalidate();

                        ShopOverview.add(ProductsOverview,BorderLayout.CENTER);
                        ShopOverview.repaint();
                        ShopOverview.revalidate();
                        
                        Toolbar.remove(NoSesionOptions);
                        Toolbar.repaint();
                        Toolbar.revalidate();
                        
                        WelcomeUserText.setText("Hola de nuevo "+currentUser.getNombre());
                        Toolbar.add(SesionOptions,BorderLayout.EAST);
                        Toolbar.repaint();
                        Toolbar.revalidate();
                    } while (usuario.next()); 
                }
            }catch(Exception e){
                e.printStackTrace();
                System.out.println("Hubo un error al llamar a la DB");
            }
           
        }
    }//GEN-LAST:event_BotonLoginMouseClicked

    private void BotonRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegistrarMouseClicked
        Cliente registrado = new Cliente();
        Connection conReg = Conexion();
        CallableStatement spRegistrar= null;
        
        try{  
            spRegistrar = conReg.prepareCall("{call Altas_Cliente(?,?,?,?,?,?,?)}");
        
            if(PassReg.getText().equals("")){
                separadorPassR.setBackground(new Color(239,83,80));
                separadorPassR.setForeground(new Color(239,83,80));
                ErrorRegPass.setText("Ingresa una Contraseña...");
            }else{
                registrado.setContraseña(PassReg.getText().toString());
                spRegistrar.setString(7, registrado.getContraseña());
                separadorPassR.setBackground(new Color(255,255,255));
                separadorPassR.setForeground(new Color(255,255,255));
                ErrorRegPass.setText("");
            }
            if(NombreReg.getText().equals("")){
                separadorNombreR.setBackground(new Color(239,83,80));
                separadorNombreR.setForeground(new Color(239,83,80));
                ErrorRegN.setText("Ingresa un nombre...");
            }else{
                registrado.setNombre(NombreReg.getText());
                spRegistrar.setString(1, registrado.getNombre());
                separadorNombreR.setBackground(new Color(255,255,255));
                separadorNombreR.setForeground(new Color(255,255,255));
                ErrorRegN.setText("");
            }
            if(ApellidosRegP.getText().equals("")){
                separadorPassR.setBackground(new Color(239,83,80));
                separadorPassR.setForeground(new Color(239,83,80));
                ErrorRegA.setText("Ingresa un apellido...");
            }else{
                registrado.setApellidoPaterno(ApellidosRegP.getText());
                spRegistrar.setString(2, registrado.getApellidoPaterno());
                separadorPassR.setBackground(new Color(255,255,255));
                separadorPassR.setForeground(new Color(255,255,255));
                ErrorRegA.setText("");
            }
            if(ApellidosRegM.getText().equals("")){
                separadorPassR.setBackground(new Color(239,83,80));
                separadorPassR.setForeground(new Color(239,83,80));
                ErrorRegA.setText("Ingresa un apellido...");
            }else{
                registrado.setApellidoMaterno(ApellidosRegM.getText());
                spRegistrar.setString(3, registrado.getApellidoMaterno());
                separadorPassR.setBackground(new Color(255,255,255));
                separadorPassR.setForeground(new Color(255,255,255));
                ErrorRegA.setText("");
            }
            if(MailReg.getText().equals("")){
                separadorMail.setBackground(new Color(239,83,80));
                separadorMail.setForeground(new Color(239,83,80));
                ErrorRegC.setText("Ingresa un correo...");
            }else if(!MailReg.getText().contains("@") && !MailReg.getText().contains(".")){
                separadorMail.setBackground(new Color(239,83,80));
                separadorMail.setForeground(new Color(239,83,80));
                ErrorRegC.setText("Ingresa bien el correo...");
            }else{
                registrado.setEmail(MailReg.getText());
                spRegistrar.setString(5, registrado.getEmail());
                separadorMail.setBackground(new Color(255,255,255));
                separadorMail.setForeground(new Color(255,255,255));
                ErrorRegC.setText("");
            }
            if(UserReg.getText().equals("")){
                separadorNombreR.setBackground(new Color(239,83,80));
                separadorNombreR.setForeground(new Color(239,83,80));
                ErrorRegU.setText("Ingresa un nombre...");
            }else{
                registrado.setUsername(UserReg.getText());
                spRegistrar.setString(4, registrado.getUsername());
                separadorNombreR.setBackground(new Color(255,255,255));
                separadorNombreR.setForeground(new Color(255,255,255));
                ErrorRegU.setText("");
            }
            if(PhoneReg.getText().equals("")){
                separadorNombreR.setBackground(new Color(239,83,80));
                separadorNombreR.setForeground(new Color(239,83,80));
                ErrorRegU.setText("Ingresa un telefono...");
            }else{
                registrado.setTelefono(PhoneReg.getText());
                spRegistrar.setString(6, registrado.getTelefono());
                separadorNombreR.setBackground(new Color(255,255,255));
                separadorNombreR.setForeground(new Color(255,255,255));
                ErrorRegU.setText("");
            }
            System.out.println("Ingresando los siguientes datos a la DB:"+registrado.toString());
            spRegistrar.execute();
            System.out.println("Se ha registrado con exito");
            JOptionPane.showMessageDialog(null,"Se ha Registrado al usuario con Exito");
            ShopOverview.remove(SignUp);
            ShopOverview.revalidate();
            ShopOverview.repaint();
            
            ShopOverview.add(Login,BorderLayout.CENTER);
            ShopOverview.revalidate();
            ShopOverview.repaint();
        }catch(Exception e){
            System.out.println("Ha ocurido un error al llamar el SP");
            e.printStackTrace();
        }
        
        
    }//GEN-LAST:event_BotonRegistrarMouseClicked

    private void ReturnLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ReturnLoginMouseClicked
        // TODO add your handling code here:
        ShopOverview.remove(Login);
        ShopOverview.repaint();
        ShopOverview.revalidate();
        
        ShopOverview.add(ProductsOverview,BorderLayout.CENTER);
        ShopOverview.repaint();
        ShopOverview.revalidate();
    }//GEN-LAST:event_ReturnLoginMouseClicked

    private void RegresarSignUpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RegresarSignUpMouseClicked
        ShopOverview.remove(SignUp);
        ShopOverview.repaint();
        ShopOverview.revalidate();
        
        ShopOverview.add(ProductsOverview,BorderLayout.CENTER);
        ShopOverview.repaint();
        ShopOverview.revalidate();
    }//GEN-LAST:event_RegresarSignUpMouseClicked

    private void LoginIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LoginIconMouseClicked
        // TODO add your handling code here:
        ShopOverview.remove(ProductsOverview);
        ShopOverview.remove(ProductsSearchResult);
        ShopOverview.remove(CarroCompras);
        ShopOverview.repaint();
        ShopOverview.revalidate();
        
        ShopOverview.add(Login,BorderLayout.CENTER);
        ShopOverview.repaint();
        ShopOverview.revalidate();
    }//GEN-LAST:event_LoginIconMouseClicked

    private void SignUpIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SignUpIconMouseClicked
        // TODO add your handling code here:
        ShopOverview.remove(ProductsOverview);
        ShopOverview.remove(ProductsSearchResult);
        ShopOverview.remove(CarroCompras);
        ShopOverview.repaint();
        ShopOverview.revalidate();
        
        ShopOverview.add(SignUp,BorderLayout.CENTER);
        ShopOverview.repaint();
        ShopOverview.revalidate();
    }//GEN-LAST:event_SignUpIconMouseClicked

    private void BuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BuscarMouseClicked
        Statement busqueda = null;
        Connection conSearch = Conexion();
        String sql = "SELECT * FROM vW_Productos_Presentaciones WHERE Nombre_Producto LIKE '%"+SearchProduct.getText()+"%'";
        
        try{
            busqueda = conSearch.createStatement();
            ResultSet productosQuery = busqueda.executeQuery(sql);
            
            if (productosQuery.next() == false) {
                    System.out.println("Ha ocurrido un error al intentar obtener los Productos");
                    JOptionPane.showMessageDialog(null, "No se encontro ningun producto con el nombre especificado");
                } else {
                        List<String> productosRSA = new ArrayList();
                        productosRSA.add("0");
                        productosRSA.add("0");
                        productosRSA.add("AAAAAAAAA");
                        productosRSA.add("0");
                        productosRSA.add("0");
                        productosRSA.add("1");
                        productosRSA.add("AAAAAA");
                        productosRSA.add("AAAAAAA");
                        productosRSA.add("AAAAA");
                        productosRSA.add("AAAAAA");
                        productosRSA.add("AAAAAA");
                        productosRSA.add("0");
                        productosRSA.add("0");
                        productosBuscarString.add(productosRSA);
                
                    do { 
                        List<String> productosRS = new ArrayList<>();
                        
                        productosRS.add(productosQuery.getString("Id_Presentacion"));
                        productosRS.add(productosQuery.getString("Id_Productos"));
                        productosRS.add(productosQuery.getString("Nombre_Producto"));
                        productosRS.add(productosQuery.getString("Precio_Venta"));
                        productosRS.add(productosQuery.getString("Precio_Compra"));
                        productosRS.add(productosQuery.getString("Id_Proveedor"));
                        productosRS.add(productosQuery.getString("Categoria"));
                        productosRS.add(productosQuery.getString("Tipo_Producto"));
                        productosRS.add(productosQuery.getString("Medida_Talla"));
                        productosRS.add(productosQuery.getString("Equipo"));
                        productosRS.add(productosQuery.getString("Marca"));
                        productosRS.add(productosQuery.getString("Estatus"));
                        productosRS.add(productosQuery.getString("Existencias"));
                        
                        productosBuscarString.add(productosRS);
                    } while (productosQuery.next()); 
                    
                    Collections.sort(productosBuscarString, new Sortbynumber());

                    for (int i = 0; i < productosBuscarString.size(); i++) {
                        Producto dummy = new Producto();
                        if (i<1){
                            System.out.println("Saltar dummy");
                        }else{
                            if (Integer.parseInt(productosBuscarString.get(i).get(1).toString()) != Integer.parseInt(productosBuscarString.get(i-1).get(1).toString())) {
                                dummy.setID(Integer.parseInt(productosBuscarString.get(i).get(1).toString()));
                                dummy.setId_Provedor(Integer.parseInt(productosBuscarString.get(i).get(5).toString()));
                                dummy.setPrecioVenta(Double.parseDouble(productosBuscarString.get(i).get(3).toString()));
                                dummy.setPrecioCompra(Double.parseDouble(productosBuscarString.get(i).get(4).toString()));
                                dummy.setNombreProducto(productosBuscarString.get(i).get(2).toString());
                                dummy.setCategoria(productosBuscarString.get(i).get(6).toString());
                                dummy.setTipoProducto(productosBuscarString.get(i).get(7).toString());
                                dummy.setEquipo(productosBuscarString.get(i).get(9).toString());
                                dummy.setMarca(productosBuscarString.get(i).get(10).toString());
                                busquedaP.add(dummy);
                            }
                        }
                    }
                    
                    BusquedaGrid.setLayout(new GridLayout(busquedaP.size(), 1, 10, 10));
                    for (int i = 0; i < busquedaP.size(); i++) {
                        List<PresentacionesProducto> presentaciones = new ArrayList<>();
                        for (int j = 0; j < productosBuscarString.size(); j++) {
                            if(busquedaP.get(i).getID() == Integer.parseInt(productosBuscarString.get(j).get(1).toString())){
                                PresentacionesProducto dummyPres = new PresentacionesProducto();
                                dummyPres.setEstatus(Integer.parseInt(productosBuscarString.get(j).get(11).toString()));
                                dummyPres.setExistencias(Integer.parseInt(productosBuscarString.get(j).get(12).toString()));
                                dummyPres.setIdProducto(Integer.parseInt(productosBuscarString.get(j).get(1).toString()));
                                dummyPres.setIdPresentacion(Integer.parseInt(productosBuscarString.get(j).get(0).toString()));
                                dummyPres.setPresentacion(productosBuscarString.get(j).get(8).toString());
                                presentaciones.add(dummyPres);
                            }
                        }
                        busquedaP.get(i).setPresentaciones(presentaciones);
                        
                        ProductoPanel panel = new ProductoPanel();
                        panel.ProductoTitle.setText(busquedaP.get(i).getNombreProducto());
                        panel.Precio.setText("$"+busquedaP.get(i).getPrecioVenta().toString());
                        panel.ProductoCat.setText(busquedaP.get(i).getCategoria());
                        panel.ProductEquipo.setText(busquedaP.get(i).getEquipo());
                        panel.ProductType.setText(busquedaP.get(i).getTipoProducto());
                        panel.ProductLabel.setText(busquedaP.get(i).getMarca());
                        panel.Imagen.setIcon(new ImageIcon("../BaseballStoreAdmin/src/Productos/"+busquedaP.get(i).getID()+".jpg"));
                        if(busquedaP.get(i).getPresentaciones().get(busquedaP.get(i).getPresentacionSeleccionada()).getEstatus()<1){
                            panel.AddKart.setIcon(null);      
                            panel.NoExistenciasLabel.setText("N/A");
                        }
                        panel.productoAsignado = busquedaP.get(i);
                        System.out.println(panel.productoAsignado.toString());
                        for (int j = 0; j < busquedaP.get(i).getPresentaciones().size(); j++) {
                            panel.Presentaciones.addItem(busquedaP.get(i).getPresentaciones().get(j).getPresentacion());
                        }
                        panelsS.add(panel);
                        BusquedaGrid.add(panel);
                        BusquedaGrid.revalidate();
                        BusquedaGrid.repaint();
                        
                        ShopOverview.remove(ProductsOverview);
                        ShopOverview.remove(CarroCompras);
                        ShopOverview.revalidate();
                        ShopOverview.repaint();
                        
                        ShopOverview.add(ProductsSearchResult);
                        ShopOverview.revalidate();
                        ShopOverview.repaint();
                        
                        pack();
                    }       
                }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hubo un error al llamar a la DB");
        }
    }//GEN-LAST:event_BuscarMouseClicked

    private void CarritoComprasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CarritoComprasMouseClicked
        double total = 0;
        for (int i = 0; i < panels.size(); i++) {
            if(panels.get(i).clicked == 1){
                kart.add(panels.get(i).productoAsignado);
                panelsC.add(panels.get(i));
                panels.get(i).clicked = 0;
            }
        }
        for (int i = 0; i < panelsS.size(); i++) {
            if(panelsS.get(i).clicked == 1){
                kart.add(panelsS.get(i).productoAsignado);
                panelsC.add(panelsS.get(i));
                panelsS.get(i).clicked = 0;
            }
        }       
        
        CarroGrid.setLayout(new GridLayout(panelsC.size(),1, 10, 10));
        for (int i = 0; i < panelsC.size(); i++) {
            total += panelsC.get(i).productoAsignado.getPrecioVenta()*panelsC.get(i).cantidad;
            panelsC.get(i).Presentaciones.setSelectedIndex(panelsC.get(i).presentacionObj);
            panelsC.get(i).Presentaciones.setEnabled(false);
            panelsC.get(i).CantidadCompra.setValue(panelsC.get(i).cantidad);
            panelsC.get(i).CantidadCompra.setEnabled(false);
            panelsC.get(i).AddKart.setVisible(false);
            CarroGrid.add(panelsC.get(i));
            CarroGrid.revalidate();
            CarroGrid.repaint();
            pack();
        }
        
        String totalProds = String.valueOf(kart.size());
        TotalProdsCarro.setText(totalProds);
        TotalPrecioCarro.setText("$"+String.valueOf(total));
        
        
        System.out.println("\n\n\nCarrito de Compras");
        for (int i = 0; i < kart.size(); i++) {
            System.out.println(kart.get(i).toString());
            System.out.println(panels.get(i).cantidad);
        }
        
        ShopOverview.remove(ProductsOverview);
        ShopOverview.remove(ProductsSearchResult);
        ShopOverview.revalidate();
        ShopOverview.repaint();

        ShopOverview.add(CarroCompras);
        ShopOverview.revalidate();
        ShopOverview.repaint();
        pack();
    }//GEN-LAST:event_CarritoComprasMouseClicked

    private void CerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CerrarSesionMouseClicked
        // TODO add your handling code here:
        int reply = JOptionPane.showConfirmDialog(null, "Estas seguro que quieres cerrar sesion?", "Estas a punto de cerrar sesion...", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "Sale pues, nos vemos luego.");
            currentUser = null;
            ShopOverview.removeAll();
            ShopOverview.revalidate();
            ShopOverview.repaint();

            WelcomeUserText.setText("");
            ShopOverview.add(ProductsOverview);
            ShopOverview.add(Toolbar);
            Toolbar.remove(SesionOptions);
            Toolbar.revalidate();
            Toolbar.repaint();
            Toolbar.add(NoSesionOptions,BorderLayout.EAST);
            Toolbar.revalidate();
            Toolbar.repaint();
        } else {
            JOptionPane.showMessageDialog(null, "Supongo te equivocaste ahi...");
        }
    }//GEN-LAST:event_CerrarSesionMouseClicked

    private void CancelEditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CancelEditMouseClicked
        // TODO add your handling code here:
        ShopOverview.remove(EditProfile);
        ShopOverview.revalidate();
        ShopOverview.repaint();
        
        ShopOverview.add(ProductsOverview,BorderLayout.CENTER);
        ShopOverview.revalidate();
        ShopOverview.repaint();
    }//GEN-LAST:event_CancelEditMouseClicked

    private void ConfirmEditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ConfirmEditMouseClicked
        // TODO add your handling code here:
        Connection conMod = Conexion();
        CallableStatement spModificar = null;
        
        try{
            spModificar = conMod.prepareCall("{call Modificar_Cliente(?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            
            spModificar.setInt(1, currentUser.getID());
            spModificar.setString(2, ENombre.getText());
            spModificar.setString(3, EApellidoP.getText());
            spModificar.setString(4, EApellidoM.getText());
            spModificar.setString(5, EUsername.getText());
            spModificar.setString(6, EMail.getText());
            spModificar.setString(7, EPhone.getText());
            spModificar.setString(8, EPass.getText());
            spModificar.setString(9, ECalle.getText());
            int interior = Integer.parseInt(ENoInt.getText());
            spModificar.setInt(10, interior);
            int exterior = Integer.parseInt(ENoExt.getText());
            spModificar.setInt(11, exterior);
            spModificar.setString(12, ECP.getText());
            spModificar.setString(13, ETA.getText());
            
            spModificar.execute();
            
            currentUser.setNombre(ENombre.getText());
            currentUser.setApellidoPaterno(EApellidoP.getText());
            currentUser.setApellidoMaterno(EApellidoM.getText());
            currentUser.setUsername(EUsername.getText());
            currentUser.setEmail(EMail.getText());
            currentUser.setTelefono(EPhone.getText());
            currentUser.setContraseña(EPass.getText());
            currentUser.setCalle(ECalle.getText());
            currentUser.setNo_Int(interior);
            currentUser.setNo_Ext(exterior);
            currentUser.setCP(ECP.getText());
            currentUser.setID_Asentamiento(ETA.getText());
            
            JOptionPane.showMessageDialog(null,"Se ha Actualizado tu informacion con Exito");
        }catch(Exception e){
            System.out.println("Ha ocurido un error al llamar el SP");
            e.printStackTrace();
        }
    }//GEN-LAST:event_ConfirmEditMouseClicked

    private void ConfiguracionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ConfiguracionMouseClicked
        // TODO add your handling code here:
        ShopOverview.remove(ProductsOverview);
        ShopOverview.remove(ProductsSearchResult);
        ShopOverview.remove(CarroCompras);
        ShopOverview.revalidate();
        ShopOverview.repaint();
        
        ShopOverview.add(EditProfile,BorderLayout.CENTER);
        ShopOverview.revalidate();
        ShopOverview.repaint();
        
        System.out.println("Se modificiara al usuario: "+currentUser.toString());
        ENombre.setText(currentUser.getNombre());
        EApellidoM.setText(currentUser.getApellidoMaterno());
        EApellidoP.setText(currentUser.getApellidoPaterno());
        EPass.setText(currentUser.getContraseña());
        EPhone.setText(currentUser.getTelefono());
        EMail.setText(currentUser.getEmail());
        EUsername.setText(currentUser.getUsername());
        ECalle.setText(currentUser.getCalle());
        ENoExt.setText(String.valueOf(currentUser.getNo_Ext()));
        ENoInt.setText(String.valueOf(currentUser.getNo_Int()));
        ECP.setText(String.valueOf(currentUser.getCP()));
        ETA.setText(String.valueOf(currentUser.getID_Asentamiento()));
    }//GEN-LAST:event_ConfiguracionMouseClicked

    private void RegresarSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RegresarSearchMouseClicked
        // TODO add your handling code here:
        for (int i = 0; i < panelsS.size(); i++) {
            if(panelsS.get(i).clicked == 1){
                kart.add(panelsS.get(i).productoAsignado);
                panelsC.add(panelsS.get(i));
                panelsS.get(i).clicked = 0;
            }
        }       
        
        busquedaP.clear();
        panelsS.clear();
        productosBuscarString.clear();
        ShopOverview.remove(ProductsSearchResult);
        BusquedaGrid.removeAll();
        ShopOverview.revalidate();
        ShopOverview.repaint();

        ShopOverview.add(ProductsOverview);
        ShopOverview.revalidate();
        ShopOverview.repaint();
        pack();
    }//GEN-LAST:event_RegresarSearchMouseClicked

    private void RegresarCarroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RegresarCarroMouseClicked
        // TODO add your handling code here:
        ShopOverview.remove(CarroCompras);
        ShopOverview.revalidate();
        ShopOverview.repaint();

        ShopOverview.add(ProductsOverview);
        ShopOverview.revalidate();
        ShopOverview.repaint();
        pack();
    }//GEN-LAST:event_RegresarCarroMouseClicked

    private void EliminarElementoCarroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EliminarElementoCarroMouseClicked
        if(Integer.parseInt(IDVaciar.getText())<1 || kart.size()<1){
            JOptionPane.showMessageDialog(null, "Esa Accion no se puede realizar");
        }else{
            kart.remove(Integer.parseInt(IDVaciar.getText())-1);
            panelsC.remove(Integer.parseInt(IDVaciar.getText())-1);
            CarroGrid.remove(Integer.parseInt(IDVaciar.getText())-1);
            CarroGrid.revalidate();
            CarroGrid.repaint();
        }        
    }//GEN-LAST:event_EliminarElementoCarroMouseClicked

    private void VaciarCarroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VaciarCarroMouseClicked
        kart.clear();
        panelsC.clear();
        CarroGrid.removeAll();
        CarroGrid.revalidate();
        CarroGrid.repaint();
        ScrollCarroCompras.revalidate();
        ScrollCarroCompras.repaint();
        ShopOverview.remove(CarroCompras);
        ShopOverview.revalidate();
        ShopOverview.repaint();
        
        ShopOverview.add(ProductsOverview);
        ShopOverview.revalidate();
        ShopOverview.repaint();
    }//GEN-LAST:event_VaciarCarroMouseClicked

    private void PreceedtoBuyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PreceedtoBuyMouseClicked
        // TODO add your handling code here:
        if(currentUser.getNombre()==null){
            JOptionPane.showMessageDialog(null,"Necesitas Iniciar Sesion o Registrarte para continuar...");
        }else if(kart.size() == 0){
            JOptionPane.showMessageDialog(null,"No hay Elementos en el carro para comprar");
        }else{
            Connection conReg = Conexion();
            CallableStatement spVenta = null;
            
            Statement callVenta = null;
            int idVenta = 0;
            try{  
                
                spVenta = conReg.prepareCall("{call VentasC(?)}");
                
                callVenta = conReg.createStatement();
                
                LocalDate currentDate = LocalDate.now();
               
                spVenta.setInt(1, currentUser.getID());
                
                //spVenta.setObject(2, currentDate);
                
                spVenta.execute();
                
                spVenta.close();
                
                String sql = "SELECT * FROM Ventas WHERE Id_Cliente='"+currentUser.getID()+"' AND Fecha='"+currentDate+"'";
                
                ResultSet traerVenta = callVenta.executeQuery(sql);
                
                if (traerVenta.next() == false) {
                    System.out.println("Ha ocurrido un error al intentar seleccionar la venta"); 
                } else { 
                    do { 
                        idVenta = traerVenta.getInt("Id_Venta");
                    } while (traerVenta.next()); 
                }
                System.out.println("3");
                traerVenta.close();
                
                System.out.println(idVenta);
                System.out.println("4");
                for (int i = 0; i < kart.size(); i++) {
                    CallableStatement spVentaProducto = null;
                    try{
                        spVentaProducto = conReg.prepareCall("{call Ventas_Producto(?,?,?,?,?)}");
                    
                        spVentaProducto.setInt(1,idVenta);
                        spVentaProducto.setInt(2,kart.get(i).getPresentaciones().get(kart.get(i).getPresentacionSeleccionada()).getIdPresentacion());
                        spVentaProducto.setInt(3,kart.get(i).getID());
                        spVentaProducto.setInt(4,panelsC.get(i).cantidad);
                        spVentaProducto.setDouble(5,kart.get(i).getPrecioVenta());

                        spVentaProducto.execute();
                        spVentaProducto.close();
                        
                    }catch(SQLException e){
                        System.out.println("Ha ocurido un error al llamar el SP Ventas_Producto");
                e.printStackTrace();
                    }
                }
                
                JOptionPane.showMessageDialog(null,"Se ha completado con exito tu compra!!!");
                ShopOverview.remove(CarroCompras);
                ShopOverview.revalidate();
                ShopOverview.repaint();
                
                ShopOverview.add(ProductsOverview);
                ShopOverview.revalidate();
                ShopOverview.repaint();
                conReg.close();
            }catch(Exception e){
                System.out.println("Ha ocurido un error al llamar el SP");
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_PreceedtoBuyMouseClicked

    private void HistorialComprasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HistorialComprasMouseClicked
        // TODO add your handling code here:
        Statement Historial = null;
        Connection conHistorial = Conexion();
        String sql = "SELECT * FROM vW_ComprasCliente where Id_Cliente = "+currentUser.getID();
        
        try{
            Historial = conHistorial.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
ResultSet.CONCUR_UPDATABLE);
            ResultSet rsHistorial = Historial.executeQuery(sql);
            if (rsHistorial.next() == false) {
                    System.out.println("Ha ocurrido un error al intentar obtener los datos");
                    JOptionPane.showMessageDialog(null, "Parece Ser que no has comprado nada aun...");
                } else {
                
                    TableModel modelo = new ResultSetTableModel(rsHistorial);
                    HistorialTabla.setModel(modelo);
                    
                    ShopOverview.remove(ProductsOverview);
                    ShopOverview.remove(ProductsSearchResult);
                    ShopOverview.remove(CarroCompras);
                    ShopOverview.revalidate();
                    ShopOverview.repaint();
                    
                    ShopOverview.add(this.Historial);
                    ShopOverview.revalidate();
                    ShopOverview.repaint();
                }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Hubo un error al llamar a la DB");
        }
    }//GEN-LAST:event_HistorialComprasMouseClicked

    private void RegresarHistorialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RegresarHistorialMouseClicked
        // TODO add your handling code here:
        ShopOverview.remove(Historial);
        ShopOverview.revalidate();
        ShopOverview.repaint();
        
        ShopOverview.add(ProductsOverview);
        ShopOverview.revalidate();
        ShopOverview.repaint();
    }//GEN-LAST:event_RegresarHistorialMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Shop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Shop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Shop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Shop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Shop().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Shop.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
        });
    }
    
    class Sortbynumber implements Comparator<List> { 
        @Override
        public int compare(List o1, List o2) {
            return Integer.parseInt(o1.get(1).toString()) - Integer.parseInt(o2.get(1).toString());
            //To change body of generated methods, choose Tools | Templates.
        }
    } 
    
    class ResultSetTableModel extends AbstractTableModel{  
   /**
      Constructs the table model.
      @param aResultSet the result set to display.
   */
   public ResultSetTableModel(ResultSet aResultSet){  
      rs = aResultSet;
      try
      {  
         rsmd = rs.getMetaData();
      }
      catch (SQLException e)
      {  
         e.printStackTrace();
      }
   }
 
   public String getColumnName(int c){  
      try
      {  
         return rsmd.getColumnName(c + 1);
      }
      catch (SQLException e)
      {  
         e.printStackTrace();
         return "";
      }
   }
 
   public int getColumnCount(){  
      try
      {  
         return rsmd.getColumnCount();
      }
      catch (SQLException e)
      {  
         e.printStackTrace();
         return 0;
      }
   }
 
   public Object getValueAt(int r, int c)
   {  
      try
      {  
         rs.absolute(r + 1);
         return rs.getObject(c + 1);
      }
      catch(SQLException e)
      {  
         e.printStackTrace();
         return null;
      }
   }
 
   public int getRowCount()
   {  
      try
      {  
         rs.last();
         return rs.getRow();
      }
      catch(SQLException e)
      {  
         e.printStackTrace();
         return 0;
      }
   }
 
   private ResultSet rs;
   private ResultSetMetaData rsmd;
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ApellidosRegM;
    private javax.swing.JTextField ApellidosRegP;
    private javax.swing.JButton BotonLogin;
    private javax.swing.JButton BotonRegistrar;
    private javax.swing.JLabel Buscar;
    private javax.swing.JPanel BusquedaGrid;
    private javax.swing.JButton CancelEdit;
    private javax.swing.JLabel CarritoCompras;
    private javax.swing.JPanel CarroCompras;
    private javax.swing.JPanel CarroGrid;
    private javax.swing.JPanel Categeorias;
    private javax.swing.JPanel Categeorias1;
    private javax.swing.JLabel CerrarSesion;
    private javax.swing.JLabel CloseApp;
    private javax.swing.JLabel Configuracion;
    private javax.swing.JButton ConfirmEdit;
    private javax.swing.JPanel CustomStateBar;
    private javax.swing.JTextField EApellidoM;
    private javax.swing.JTextField EApellidoP;
    private javax.swing.JTextField ECP;
    private javax.swing.JTextField ECalle;
    private javax.swing.JTextField EMail;
    private javax.swing.JTextField ENoExt;
    private javax.swing.JTextField ENoInt;
    private javax.swing.JTextField ENombre;
    private javax.swing.JTextField EPass;
    private javax.swing.JTextField EPhone;
    private javax.swing.JTextField ETA;
    private javax.swing.JTextField EUsername;
    private javax.swing.JPanel EditPanel;
    private javax.swing.JPanel EditProfile;
    private javax.swing.JButton EliminarElementoCarro;
    private javax.swing.JLabel ErrorName;
    private javax.swing.JLabel ErrorPass;
    private javax.swing.JLabel ErrorRegA;
    private javax.swing.JLabel ErrorRegC;
    private javax.swing.JLabel ErrorRegN;
    private javax.swing.JLabel ErrorRegPass;
    private javax.swing.JLabel ErrorRegU;
    private javax.swing.JLabel FondoEdit;
    private javax.swing.JLabel FondoRegistrar;
    private javax.swing.JLabel FondoVenta;
    private javax.swing.JLabel FondoVenta1;
    private javax.swing.JLabel FondoVenta2;
    private javax.swing.JLabel FondoVenta3;
    private javax.swing.JPanel Footer;
    private javax.swing.JPanel Historial;
    private javax.swing.JLabel HistorialCompras;
    private javax.swing.JTable HistorialTabla;
    private javax.swing.JTextField IDVaciar;
    private javax.swing.JPanel Login;
    private javax.swing.JLabel LoginBackGround;
    private javax.swing.JLabel LoginIcon;
    private javax.swing.JTextField MailReg;
    private javax.swing.JLabel Minimize;
    private javax.swing.JLabel Name;
    private javax.swing.JPanel NoSesionOptions;
    private javax.swing.JTextField NombreReg;
    private javax.swing.JPanel PanelEntrada;
    private javax.swing.JPanel PanelRegistro;
    private javax.swing.JPasswordField PassField;
    private javax.swing.JTextField PassReg;
    private javax.swing.JTextField PhoneReg;
    private javax.swing.JButton PreceedtoBuy;
    private javax.swing.JPanel ProductsGrid;
    private javax.swing.JPanel ProductsOverview;
    private javax.swing.JPanel ProductsSearchResult;
    private javax.swing.JLabel RegresarCarro;
    private javax.swing.JLabel RegresarHistorial;
    private javax.swing.JLabel RegresarSearch;
    private javax.swing.JLabel RegresarSignUp;
    private javax.swing.JLabel ReturnLogin;
    private javax.swing.JScrollPane ScrollCarroCompras;
    private javax.swing.JScrollPane ScrollSearch;
    private javax.swing.JSeparator SearchBar;
    private javax.swing.JLabel SearchIcon;
    private javax.swing.JPanel SearchKart;
    private javax.swing.JTextField SearchProduct;
    private javax.swing.JPanel SearchTV;
    private javax.swing.JPanel SearchTV1;
    private javax.swing.JPanel SearchTV2;
    private javax.swing.JSeparator SeparadorUsername;
    private javax.swing.JSeparator SeparadorUsername1;
    private javax.swing.JPanel SesionOptions;
    private javax.swing.JPanel ShopOverview;
    private javax.swing.JPanel SignUp;
    private javax.swing.JLabel SignUpIcon;
    private javax.swing.JScrollPane SrollPO;
    private javax.swing.JLabel TextoLogin1;
    private javax.swing.JLabel TextoPass;
    private javax.swing.JLabel TextoPass1;
    private javax.swing.JLabel TextoPass2;
    private javax.swing.JLabel TextoPass3;
    private javax.swing.JLabel TextoPass4;
    private javax.swing.JLabel TextoPass6;
    private javax.swing.JLabel TextoRegistro;
    private javax.swing.JLabel TextoTel;
    private javax.swing.JLabel TextoUser;
    private javax.swing.JPanel Toolbar;
    private javax.swing.JLabel TotalPrecioCarro;
    private javax.swing.JLabel TotalProdsCarro;
    private javax.swing.JTextField UserField;
    private javax.swing.JTextField UserReg;
    private javax.swing.JButton VaciarCarro;
    private javax.swing.JLabel WelcomeUserText;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator separadorApellidosR;
    private javax.swing.JSeparator separadorApellidosRP;
    private javax.swing.JSeparator separadorMail;
    private javax.swing.JSeparator separadorNombre;
    private javax.swing.JSeparator separadorNombreR;
    private javax.swing.JSeparator separadorPassR;
    private javax.swing.JSeparator separadorPassword;
    // End of variables declaration//GEN-END:variables
}
