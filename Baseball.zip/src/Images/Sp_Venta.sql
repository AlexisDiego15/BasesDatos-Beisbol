use Baseball_Store
GO
Create Procedure Ventas
@id_Cliente int,
@Fecha datetime
AS
Begin
Begin tran

	INSERT INTO Ventas(Id_Cliente,Fecha)
	Values ( (select Id_Cliente from Clientes where Id_Cliente=@id_Cliente),@Fecha)
	
	 
COMMIT TRAN
END
----
Create Procedure Ventas_Producto
@Id_Venta int,
@Id_Presenatcion int,
@Id_Productos int,
@Cantidad int,
@Precio_uni decimal,
@Existencias int
AS
Begin
	Begin Tran
	if(@cantidad<=(select Existencias from Presentacion where Id_Presentacion=@Id_Presenatcion)) 
	BEGIN
	Set @Existencias=(select Existencias from Presentacion where Id_Presentacion=@Id_Presenatcion)-@cantidad
	Update Presentacion Set Existencias=@Existencias
	Insert into Ventas_Producto(Id_Venta,Id_Presentacion,Id_Productos,Cantidad,Precio_Unitario_Venta)
	Values((Select Id_Venta From Ventas where Id_Venta=@Id_Venta),(Select Id_Presentacion From Presentacion where Id_Presentacion=@Id_Presenatcion),
	(Select Id_Productos From Productos where Id_Productos=@Id_Productos),@Cantidad,@Precio_uni)
	END 
	COMMIT TRAN
END