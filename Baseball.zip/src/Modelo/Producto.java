/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;
import Modelo.PresentacionesProducto;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MrJua
 */
public class Producto {
    
    private int ID, Id_Provedor, PresentacionSeleccionada;
    private Double PrecioVenta, PrecioCompra;
    private String NombreProducto, Categoria, TipoProducto, Equipo, Marca;
    private List<PresentacionesProducto> presentaciones;

    public Producto() {
    }

    public Producto(int ID, int Id_Provedor, Double PrecioVenta, Double PrecioCompra, String NombreProducto, String Categoria, String TipoProducto, String Equipo, String Marca) {
        this.ID = ID;
        this.Id_Provedor = Id_Provedor;
        this.PrecioVenta = PrecioVenta;
        this.PrecioCompra = PrecioCompra;
        this.NombreProducto = NombreProducto;
        this.Categoria = Categoria;
        this.TipoProducto = TipoProducto;
        this.Equipo = Equipo;
        this.Marca = Marca;
    }
    
    public int getPresentacionSeleccionada() {
        return PresentacionSeleccionada;
    }

    public void setPresentacionSeleccionada(int PresentacionSeleccionada) {
        this.PresentacionSeleccionada = PresentacionSeleccionada;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getId_Provedor() {
        return Id_Provedor;
    }

    public void setId_Provedor(int Id_Provedor) {
        this.Id_Provedor = Id_Provedor;
    }

    public Double getPrecioVenta() {
        return PrecioVenta;
    }

    public void setPrecioVenta(Double PrecioVenta) {
        this.PrecioVenta = PrecioVenta;
    }

    public Double getPrecioCompra() {
        return PrecioCompra;
    }

    public void setPrecioCompra(Double PrecioCompra) {
        this.PrecioCompra = PrecioCompra;
    }

    public String getNombreProducto() {
        return NombreProducto;
    }

    public void setNombreProducto(String NombreProducto) {
        this.NombreProducto = NombreProducto;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }

    public String getTipoProducto() {
        return TipoProducto;
    }

    public void setTipoProducto(String TipoProducto) {
        this.TipoProducto = TipoProducto;
    }

    public String getEquipo() {
        return Equipo;
    }

    public void setEquipo(String Equipo) {
        this.Equipo = Equipo;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public List<PresentacionesProducto> getPresentaciones() {
        return presentaciones;
    }

    public void setPresentaciones(List<PresentacionesProducto> presentaciones) {
        this.presentaciones = presentaciones;
    }

    

    @Override
    public String toString() {
        return "Producto{" + "\n\tID=" + ID + "\n\tPrecioVenta=" + PrecioVenta + "\n\tPrecioCompra=" + PrecioCompra + "\n\tId_Provedor=" + Id_Provedor + "\n\tNombreProducto=" + NombreProducto + "\n\tCategoria=" + Categoria + "\n\tTipoProducto=" + TipoProducto + "\n\tEquipo=" + Equipo + "\n\tMarca=" + Marca + "\n\tpresentaciones=" + presentaciones + '}';
    }

    
}
