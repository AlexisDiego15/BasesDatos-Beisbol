/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author MrJua
 */
public class PresentacionesProducto {
    
    private int idPresentacion, Estatus, Existencias, idProducto;
    private String Presentacion;

    public PresentacionesProducto() {
    }

    public PresentacionesProducto(int idPresentacion, int Estatus, int Existencias, int idProducto, String Presentacion) {
        this.idPresentacion = idPresentacion;
        this.Estatus = Estatus;
        this.Existencias = Existencias;
        this.idProducto = idProducto;
        this.Presentacion = Presentacion;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }
    
    public int getIdPresentacion() {
        return idPresentacion;
    }

    public void setIdPresentacion(int idPresentacion) {
        this.idPresentacion = idPresentacion;
    }

    public int getEstatus() {
        return Estatus;
    }

    public void setEstatus(int Estatus) {
        this.Estatus = Estatus;
    }

    public int getExistencias() {
        return Existencias;
    }

    public void setExistencias(int Existencias) {
        this.Existencias = Existencias;
    }

    public String getPresentacion() {
        return Presentacion;
    }

    public void setPresentacion(String Presentacion) {
        this.Presentacion = Presentacion;
    }

    @Override
    public String toString() {
        return "PresentacionesProducto{" + "idPresentacion=" + idPresentacion + ", Estatus=" + Estatus + ", Existencias=" + Existencias + ", idProducto=" + idProducto + ", Presentacion=" + Presentacion + '}';
    }
    
}
