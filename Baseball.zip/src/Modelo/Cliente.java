/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author MrJua
 */
public class Cliente {
    
    private String Nombre , Username , ApellidoPaterno , ApellidoMaterno , Email , Contraseña , Telefono, Calle, ID_Asentamiento,CP;
    private int ID , No_Int , No_Ext;

    public Cliente() {
    }

    public Cliente(String Nombre, String Username, String ApellidoPaterno, String ApellidoMaterno, String Email, String Contraseña, String Telefono, String Calle, int ID, int No_Int, int No_Ext, String CP, String ID_Asentamiento) {
        this.Nombre = Nombre;
        this.Username = Username;
        this.ApellidoPaterno = ApellidoPaterno;
        this.ApellidoMaterno = ApellidoMaterno;
        this.Email = Email;
        this.Contraseña = Contraseña;
        this.Telefono = Telefono;
        this.Calle = Calle;
        this.ID = ID;
        this.No_Int = No_Int;
        this.No_Ext = No_Ext;
        this.CP = CP;
        this.ID_Asentamiento = ID_Asentamiento;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getApellidoPaterno() {
        return ApellidoPaterno;
    }

    public void setApellidoPaterno(String ApellidoPaterno) {
        this.ApellidoPaterno = ApellidoPaterno;
    }

    public String getApellidoMaterno() {
        return ApellidoMaterno;
    }

    public void setApellidoMaterno(String ApellidoMaterno) {
        this.ApellidoMaterno = ApellidoMaterno;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public String getCalle() {
        return Calle;
    }

    public void setCalle(String Calle) {
        this.Calle = Calle;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getNo_Int() {
        return No_Int;
    }

    public void setNo_Int(int No_Int) {
        this.No_Int = No_Int;
    }

    public int getNo_Ext() {
        return No_Ext;
    }

    public void setNo_Ext(int No_Ext) {
        this.No_Ext = No_Ext;
    }

    public String getCP() {
        return CP;
    }

    public void setCP(String CP) {
        this.CP = CP;
    }

    public String getID_Asentamiento() {
        return ID_Asentamiento;
    }

    public void setID_Asentamiento(String ID_Asentamiento) {
        this.ID_Asentamiento = ID_Asentamiento;
    }

    @Override
    public String toString() {
        return "Cliente{" + "Nombre=" + Nombre + ", Username=" + Username + ", ApellidoPaterno=" + ApellidoPaterno + ", ApellidoMaterno=" + ApellidoMaterno + ", Email=" + Email + ", Contrase\u00f1a=" + Contraseña + ", Telefono=" + Telefono + ", Calle=" + Calle + ", ID=" + ID + ", No_Int=" + No_Int + ", No_Ext=" + No_Ext + ", CP=" + CP + ", ID_Asentamiento=" + ID_Asentamiento + '}';
    }
    
}
